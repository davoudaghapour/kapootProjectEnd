import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    Brands:[],
    Cars:[]
};

const BrandsCarsSlice = createSlice({
    name: 'brands_cars',
    initialState: initialState,
    reducers: {
        setBrands:(state, action)=>{
            return {...state , Brands:[...action.payload]}
        },
        setCars:(state, action)=>{
            return {...state , Cars:[...action.payload]}
        }
    },
})

export const { setBrands,setCars } = BrandsCarsSlice.actions ;

export default BrandsCarsSlice.reducer


/*
const initialState = [];

const BrandsSlice = createSlice({
    name: 'brands',
    initialState: initialState,
    reducers: {
        setBrands:(state, action)=>{
            return [...action.payload]
        }
    },
})

export const { setBrands } = BrandsSlice.actions ;

export default BrandsSlice.reducer
*/