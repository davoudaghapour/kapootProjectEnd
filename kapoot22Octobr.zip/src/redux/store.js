import { configureStore } from "@reduxjs/toolkit";
import userSlice from "./UserReducer/userSlice";
import citiesSlice, { cityModalStatus } from "./CityReducer/CitySlice";
import StoreSlice from "./StoreReducer/StoreSlice";
import BrandsCarsSlice from "./Brands.Cars_Reducer/BrandSlice";
import PostsSlice from "./PostsReducer/PostsSlice";
import CartSlice, { cartMenuSlice } from "./CartReducer/CartSlice";
import SiteInfoSlice from "./SiteInfoReducer/SiteInfoSlice";
import SiteMenuSlice from "./SiteMenuReducer/SiteMenuSlice";
import CarsSlice from "./Brands.Cars_Reducer/CarsSlice";
import storiesSlice from "./StoriesRecucer/storiesSlice";



const store = configureStore({
    reducer: {
        userInfo: userSlice,
        citySolector: cityModalStatus.reducer,
        citiesList: citiesSlice,
        storeInfo: StoreSlice,
        posts: PostsSlice,
        cart: CartSlice,
        cartSideMenuStatus: cartMenuSlice,
        _siteInfo: SiteInfoSlice,
        _stories: storiesSlice,
        _siteMenu: SiteMenuSlice,
        _cars: CarsSlice,
        //_brands:BrandSlice,
        _brand_car: BrandsCarsSlice, //=>   brands and cars set in a object together
    }
})

export default store