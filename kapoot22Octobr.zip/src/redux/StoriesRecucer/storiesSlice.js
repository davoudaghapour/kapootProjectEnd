///////////////////  set item of SiteMenu in a glodal state //////////////
import { createSlice } from '@reduxjs/toolkit'

const initialState = {}

const storiesSlice = createSlice({
    name: 'stories',
    initialState: initialState,
    reducers: {
        setStories:(state, action)=>{
            return [...action.payload] // withOut ...  => [[1,2,3,3]]   ////  with ...   => [1,2,3,4]
        }
    },
})

export const { setStories } = storiesSlice.actions ;

export default storiesSlice.reducer
