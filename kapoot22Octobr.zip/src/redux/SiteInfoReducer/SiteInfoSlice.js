///////////////////  set SiteInfo in a glodal state //////////////
import { createSlice } from '@reduxjs/toolkit'

const initialState = {}

const SiteInfoSlice = createSlice({
    name: 'siteInfo',
    initialState: initialState,
    reducers: {
        setSiteInfo:(state, action)=>{
            return action.payload // withOut ...  => [[1,2,3,3]]   ////  with ...   => [1,2,3,4]
        }
    },
})

export const { setSiteInfo } = SiteInfoSlice.actions ;

export default SiteInfoSlice.reducer
