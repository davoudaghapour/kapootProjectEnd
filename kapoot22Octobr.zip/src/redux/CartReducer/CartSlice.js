import { createSlice } from '@reduxjs/toolkit'

const initialState = [];
const cartMenuStatus = {
    value: false
}

export const cartListSlice = createSlice({
    name: 'cartList',
    initialState: initialState,
    reducers: {
        addToCart: (state, actions) => {
            return [...state, { id: `CI:${state.length + 1}`, postId: actions.payload, count: 1 }];
        },
        removeFromCart: (state, actions) => {
            return [...state.filter(item => item.postId != actions.payload)];
        },
        updatteCartCount: (state, actions) => {
            return [
                ...state.map(item => item.postId == actions.payload.id ? { ...item, count: actions.payload.value } : item)
            ]
        },
        cartItemIncrement: (state, actions) => {
            return [
                ...state.map(item => item.id == actions.payload.id ? { ...item, count: actions.payload.value } : item)
            ]
        },
        cartItemDecrement: (state, actions) => {
            return [
                ...state.map(item => item.id == actions.payload.id ? { ...item, count: actions.payload.value } : item)
            ]
        },
    },
})

export const {addToCart ,removeFromCart ,updatteCartCount } = cartListSlice.actions ;

export default cartListSlice.reducer

//__________ This slice is for open / close cart sidemenu ....
const cartMenu = createSlice({
    name: 'cartMenu',
    initialState: cartMenuStatus,
    reducers: {
        openCartMenu: (state) => { state.value = true },
        closeCartMenu: (state) => { state.value = false }
    },
})

export const { openCartMenu, closeCartMenu } = cartMenu.actions
export const cartMenuSlice = cartMenu.reducer