///////////////////  set item of SiteMenu in a glodal state //////////////
import { createSlice } from '@reduxjs/toolkit'

const initialState = {}

const SiteMenuSlice = createSlice({
    name: 'siteMenu',
    initialState: initialState,
    reducers: {
        setSiteMenu:(state, action)=>{
            return [...action.payload] // withOut ...  => [[1,2,3,3]]   ////  with ...   => [1,2,3,4]
        }
    },
})

export const { setSiteMenu } = SiteMenuSlice.actions ;

export default SiteMenuSlice.reducer
