

class apiService {
    constructor(endpoint){
        this.endpoint = endpoint
        this.basic_api = 'http://localhost:3000/api/'    
        this.API = this.basic_api + endpoint
    }

    getAll(){
        const result = fetch(this.API)
            .then(response => response.json() )
        return result
    }
    delete(id){
        return fetch(this.API + id ,{
            method:'Delete',
        })
        
    }
    update(id , newObject){
        return fetch(this.API + id ,{
            method:'Put',
            body: newObject
        })
        
    }
    post(newObject){
        return fetch(this.API , {
            method:'Post',
            body: newObject 
        })
    }
}

export const usersRequest = new apiService('users/')
export const productRequest = new apiService('products/')
export const ordersRequest = new apiService('orders/')
export const offsRequest = new apiService('offs/')
export const commentsRequest = new apiService('comments/')


