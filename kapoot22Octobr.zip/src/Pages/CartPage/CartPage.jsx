import { useRef, useState } from 'react'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { FaTrashAlt } from 'react-icons/fa'
import { useOutClicker } from '../../Hook/useOutsideClick'
import { useSeparate } from '../../Hook/useNumbers'
import SupportWidget from '../../components/SupportWidget/SupportWidget'
import CartSidePanel from '../../components/CartSidePanels/CartSidePanel'
import CountInput from '../../components/CounterInput/CountInput'
import ModalContainer from '../../ModalContainer/ModalContainer'
import './CartPage.css'

// Exampel for cart items...
const example_orderList = new Array(2).fill().map((e, id) => ({ id: id, tilte: 'عنوان محصول', count: 1 }))
const exampel_storeList = Array.from(Array(2).keys())

const CartPage = () => {
    const [contactModal, setContactModal] = useState(false)
    const [cartItems, setCartItems] = useState(example_orderList)
    const [modal_ref, closeAction] = useOutClicker(setContactModal)

    /////// Data - Get cart list fro redux //////////////////
    const cartList = useSelector(state => state.cart)

    let store_id = useRef(null)

    const countManualChange = (v, itemId) => {
        let newList = cartItems.map(i => i.id == itemId ? { ...i, count: Number(v) } : i);
        setCartItems(newList)
    }

    const countChange = (n, itemId) => {
        let newList = cartItems.map(i => i.id == itemId ? { ...i, count: i.count + n } : i);
        setCartItems(newList)
    }

    const openStoreContactModal = (id) => {
        store_id.current = id;
        setContactModal(true)
    }
    return (<>
        <main className='container my-2'>
            <header className="my-1">
                <h2>سبد خرید</h2>
            </header>
            <div className="main-content_6">
                <div className="cart-content">

                    {exampel_storeList.map(store =>

                        <div key={store} className="card table-wrapper_6">
                            <div className="h5 store-title_6">
                                نام فروشگاه
                            </div>
                            <div className="scroll-area_6 no-scrollbar">

                                <table className="table_6" >
                                    <thead>
                                        <tr>
                                            <th>x</th>
                                            <th>تصویر</th>
                                            <th>نام محصول</th>
                                            <th>خودرو</th>
                                            <th>تعداد و قیمت واحد</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {cartItems.map(item =>
                                            <tr key={item.id}>
                                                <td>
                                                    <span className='remove-icon_6'>
                                                        <FaTrashAlt size={18} />
                                                    </span>
                                                </td>
                                                <td className='image_6'>
                                                    <img src="/public/Images/no-image.webp" alt="" />
                                                </td>
                                                <td>
                                                    {item.tilte}  اضافه شده به سبد خرید
                                                </td>
                                                <td>پژو پارس</td>
                                                <td>
                                                    <span>
                                                        {useSeparate(230000)}
                                                        <small>{' تومان'}  </small>
                                                    </span>
                                                    <CountInput
                                                        className="counter_6"
                                                        value={item.count}
                                                        onInputValue={(value) => countManualChange(value, item.id)}
                                                        onMinus={() => countChange(-1, item.id)}
                                                        onPluse={() => countChange(1, item.id)}
                                                    />
                                                </td>

                                            </tr>

                                        )}

                                    </tbody>
                                </table>

                            </div>
                            <div className="button-group_6">
                                <div className="total-price_6 font-lg">
                                    <span>
                                        جمع کل:
                                    </span>
                                    <span>
                                        ۳۰۰۰۰ تومان
                                    </span>
                                </div>
                                <Link to={'/cart/payment'} className="btn btn-animate p-btn_6">
                                    پرداخت
                                </Link>
                                <button className="btn btn-animate e-btn_6" onClick={() => openStoreContactModal(1)}>
                                    استعلام قیمت
                                </button>
                            </div>
                        </div>

                    )}
                </div>
                <div className="cart-summary_6">
                    <CartSidePanel values={[]} />
                </div>
            </div>
            {contactModal &&
                <ModalContainer onClick={closeAction}>
                    <div ref={modal_ref} className="estealam-modal_6">
                        <div className="modal-header_6">
                            <span>
                                استعلام قیمت
                            </span>
                            <span className="modal-close_6" onClick={() => setContactModal(false)}>
                                &#10006;
                            </span>
                        </div>
                        <p>
                            برای استعلام قیمت می‌توانید از طریق یکی از راه‌های زیر با فروشنده تماس گرفته و از عدم تغیر قیمت اقلام لیست شده اطمینان حاصل کنید.
                        </p>
                        <ul className="modal-numbers_6">
                            <li className="modal-item_6">
                                <span>
                                    شماره فروشنده:
                                </span>
                                <a href="tel:+">
                                    09147521321
                                </a>
                            </li>
                            <li className="modal-item_6">
                                <span>
                                    شماره فروشگاه:
                                </span>
                                <a href="tel:+">
                                    09147521321
                                </a>
                            </li>
                        </ul>
                    </div>
                </ModalContainer>
            }
        </main>
        <SupportWidget scrollBtn={false} />
    </>)
}

export default CartPage