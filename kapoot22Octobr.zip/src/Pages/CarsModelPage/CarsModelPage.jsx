import { useEffect, useState } from 'react'
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { FaScroll, FaWrench } from 'react-icons/fa6'
import './CarsModelPage.css' // Css Code => 22
import InformationBox from '../../components/CarsModelPage.InformationBox/InformationBox'
import BreadCrumbs from '../../components/BreadCrumbs/BreadCrumbs'
import SupportWidget from '../../components/SupportWidget/SupportWidget'
import Loading from '../../components/Loading/Loading'


const CarsModelPage = () => {
    const params = useParams()
    const navigate = useNavigate()
    const location = useLocation()
    const [brandInfo, setBrandInfo] = useState(null)
    const [carsList, setCarsList] = useState(null)

    ///////// Data - Get Cars list from redux //////////////////
    const Brands_List = useSelector(state => state._brand_car) 

    useEffect(() => {
        ////////  Ckeck Brands list to find brand with url /////////
        const brand = Brands_List.Brands.find(b => b.url == params.brandName)
        brand ? setBrandInfo(brand) : navigate('/page-not-found')

        window.scroll({ behavior: 'instant', top: 0, left: 0 })
        return () => window.scroll({ behavior: 'instant', top: 0, left: 0 })
    }, [location])

    useEffect(() => {
        if (brandInfo) {
            document.title = `فروشگاه آنلاین لوازم یدکی ${'کاپوت'} - لوازم یدکی ${brandInfo.title}`
            setCarsList(Brands_List.Cars.filter(item => item.parentID == brandInfo.id))
        }
    }, [brandInfo])


    if (!carsList) return <Loading />
    return (<>
        <BreadCrumbs />
        <main>
            <div className="container models-holder_22">
                <ul className="content_22">
                    {carsList.map(car =>
                        <li key={car.id} className="model-item_22">
                            <div className="card_22">
                                <div className="image_22">
                                    <img src={car.img} alt={car.title} />
                                </div>
                                <span>
                                    {car.title}
                                </span>
                                <div className="card-btn_22">

                                    <Link to={`/specifications/${brandInfo.title}/${car.title}`}>
                                        <span> <FaWrench /> </span>
                                        مشخصات فنی
                                    </Link>
                                    <Link to={`/posters/${brandInfo.title}/${car.title}`} >
                                        <span> <FaScroll /> </span>
                                        مشاهده قطعات
                                    </Link>
                                </div>
                            </div>
                        </li>
                    )}
                </ul>
            </div>
            <InformationBox />
        </main>
        <SupportWidget scrollBtn={false} />
    </>)
}
export default CarsModelPage