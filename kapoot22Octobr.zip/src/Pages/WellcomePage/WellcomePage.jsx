import React, { useEffect, useRef } from 'react'
import './WellcomePage.css'

const WellcomePage = ({ preview, closeHandler }) => {
    const content = useRef(null)
    const timer = useRef(3000)
    const elemStyle = {
        backgroundColor: '#e5ec09',
        animationDuration: '500ms',
        animationDelay: `${timer.current}ms`
    }
    //console.log(preview)
    useEffect(() => {
        document.documentElement.style.overflowY = 'hidden';
        return () => document.documentElement.style.overflowY = 'auto';
    }, [])
    
        const timerId = setTimeout(() => {
            closeHandler()
        }, timer.current + 505)
    /*
    useEffect(() => {
        if (!preview) {
            content.current.style.opacity = '0'
            setTimeout(() => {
                closeHandler()
            }, 100);
        }
    }, [preview])
*/
    return (
        <div ref={content} className="wellcome_009" style={elemStyle}>
            <div className="card_009">
                wellcome to
                <img src="logo.webp" alt="" />
            </div>
        </div>
    )
}

export default WellcomePage