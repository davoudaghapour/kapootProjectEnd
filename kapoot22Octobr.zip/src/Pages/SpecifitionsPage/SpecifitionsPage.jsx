import React from 'react'
import './SpecifitionsPage.css'

const SpecifitionsPage = () => {
    return (
        <main>
            <div className="card my-2">
                <span className="h1">
                    صفحه مشخصات فنی خودرو
                </span>
            </div>
        </main>
    )
}

export default SpecifitionsPage