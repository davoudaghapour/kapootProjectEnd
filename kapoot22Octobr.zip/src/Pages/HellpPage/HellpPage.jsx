import React from 'react'
import SupportWidget from '../../components/SupportWidget/SupportWidget'

const HellpPage = () => {
  return (<>
    <main className="container">
        صفحه راهنمای خرید
    </main>
    <SupportWidget scrollBtn={false} />
  </>)
}

export default HellpPage