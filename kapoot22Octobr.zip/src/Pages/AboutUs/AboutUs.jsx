import BreadCrumbs from '../../components/BreadCrumbs/BreadCrumbs'
import './AboutUs.css' // Code => 18 

const AboutUs = () => {
    return (<>
        <BreadCrumbs />
        <div className="container about-main_18">
            <section className="card"  >
                <h3> درباره ما </h3>
            </section>
        </div>
    </>)
}

export default AboutUs