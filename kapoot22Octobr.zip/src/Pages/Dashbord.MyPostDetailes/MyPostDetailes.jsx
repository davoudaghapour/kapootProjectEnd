import React from 'react'// Code => 83

const MyPostDetailes = () => {
  return (
    <div>MyPostDetailes</div>
  )
}

export default MyPostDetailes