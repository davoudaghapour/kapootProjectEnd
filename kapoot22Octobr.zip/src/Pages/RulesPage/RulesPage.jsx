import React from 'react'
import SupportWidget from '../../components/SupportWidget/SupportWidget'

const RulesPage = () => {
  return (<>
    <main className="container">
        صفحه قوانین و مقررات
    </main>
    <SupportWidget scrollBtn={false} />
  </>)
}

export default RulesPage