import { useEffect, useState } from 'react'
import { useLocation, useParams } from 'react-router-dom'
import BreadCrumbs from '../../components/BreadCrumbs/BreadCrumbs'
import SupportWidget from '../../components/SupportWidget/SupportWidget'
import PostsGridLayout from '../../components/PostsGridLayout/PostsGridLayout'
import { useSelector } from 'react-redux'

const AgahyhaPage = () => {
   const Get_Posts = useSelector(state => state.posts)
   const [postsList, setPostsList] = useState(Get_Posts)

   const params = useParams()
   const location = useLocation()

   useEffect(() => {
      document.title = 'لوازم یدکی ' + params.carModel + " | کاپوت"
   }, [])

   useEffect(()=>{
      if(location.search){
         const searchValue =location.search.replace('?search=','')
         setPostsList(prevent => prevent.filter(post => post.title.includes(searchValue)))
         console.log(`آگهی‌هایی که دارای عبارت "${searchValue}" میباشد نمایش داده میشود`)
      }
   },[location])


   return (<>
      <BreadCrumbs />
      <main className="container my-2">

         <PostsGridLayout itemList={postsList} />

      </main>
      <SupportWidget />
   </>)
}

export default AgahyhaPage