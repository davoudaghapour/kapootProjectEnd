const useImageListCreator = (listOfFiles, id = 1)=>{
    return listOfFiles.map((item, idx) => {
        return {
            id: idx + id,
            file: (typeof item === 'object') ? item : null,
            url: (typeof item === 'string') ? item : URL.createObjectURL(item),
        }
    })
}

export default useImageListCreator