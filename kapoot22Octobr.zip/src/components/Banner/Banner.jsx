import './Banner.css' // Code => 12
import SliderContent from '../Slider/SliderContent';
import { NextArrow, PrevArrow } from './SliderCustomArrow';
import { useSelector } from 'react-redux';

const Exampel_BannerList = new Array(8).fill().map((e, i) => ({ id: `bnr:${i + 1}`, imgURL: `banner-T0${i + 1}.jpg` }))

const Banner = () => {
    ////////// Data - Get Banner list from redux //////////////////////
    const banners = useSelector(state => state._siteInfo.Banners)

    const BannerSlider_Settings = {
        className: 'banner-slider-21',
        fade: true,
        nextArrow: <NextArrow />,
        prevArrow: <PrevArrow />,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    arrows: false,
                }
            }
        ]
    }

    return (
        <div className='container sliders-holder_12'>

            <SliderContent setting={BannerSlider_Settings}  >
                {Exampel_BannerList.map(banner =>

                    <div key={banner.id} className='banner-image_12'>
                        <img src={`/Banners/${banner.imgURL}`} alt="فروش قطعات خودرویی کاپوت" />
                    </div>
                )}

            </SliderContent>

        </div>

    )
}

export default Banner