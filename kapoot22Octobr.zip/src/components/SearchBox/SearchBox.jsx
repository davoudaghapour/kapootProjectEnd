import { useRef, useState } from 'react'
import './SearchBox.css' // Code => 15
import { BsArrowRight, BsSearch } from "react-icons/bs";
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

const SearchBox = ({ className = '' }) => {
    const navigate = useNavigate()
    const Search_Ref = useRef(null)
    let searchInput = useRef('')
    let isActive = useRef(false)
    const [results, setResultes] = useState([])

    ///////////// Get Ads from redux ////////////////////
    const orginalData = useSelector(state => state.posts)
    ///////////// Get site name  from redux /////////////
    const siteName = useSelector(state => state._siteInfo?.SiteName)
    ////////////////////////////////////////////////////

    const openResultBox = () => {
        Search_Ref.current.classList.add('open_15')
        document.documentElement.style.overflowY = 'hidden';
        isActive.current = true;
    }

    const closeResultBox = () => {
        searchInput.current = '';
        Search_Ref.current.classList.remove('open_15');
        document.documentElement.style.overflowY = 'auto';
        isActive.current = false;
        setResultes([])
    }

    const inputChange = (e) => {
        searchInput.current = e.target.value
        const searchValue = e.target.value.toLowerCase();
        (!searchValue && window.innerWidth >= 768) ? closeResultBox() : openResultBox()

        ////////////////  Searching in Ads data ////////
        const result = orginalData.filter(item => item.title.includes(searchValue))
        searchValue ? setResultes(result) : setResultes([]);
    }

    const onSearchHandler = (payload) => {
        if (searchInput.current == '') return;
        console.log('Cliked on search result => ' + payload)

        payload ? navigate('?search=' + payload.title)// The link of resulte will add here ...
            : navigate('/posters/کیا/سراتو/category/?search=' + searchInput.current)// The link of resulte will add here ...
        
            closeResultBox()
    }

    const onSearchIconClick = () => {
        window.innerWidth <= 768 ?
            isActive.current ? onSearchHandler(null) : openResultBox() : onSearchHandler(null);
    }

    return (
        <div ref={Search_Ref} className={`search-15 ${className}`}>
            <div className="back-icon-15" onClick={closeResultBox}>
                <BsArrowRight size={20} />
            </div>
            <div className="search-input-15">
                <input
                    id='input:search'
                    placeholder={`جستجو در ${siteName}`}
                    type="search"
                    value={searchInput.current}
                    onChange={inputChange}
                />
                <span className='icon-15 btn-primary btn-animate' onClick={onSearchIconClick}>
                    <BsSearch size={'100%'} />
                </span>
            </div>

            <div className="result-content-15">
                <div className="hedding-15">
                    {results.length != 0
                        ? <span> {results.length} تا پیدا شد!</span>
                        : <span> موردی یافت نشد </span>
                    }
                </div>
                <ul className="">
                    {results.map((res, index) =>
                        <li key={`si:${index}`} onClick={() => onSearchHandler(res)} >
                            {res.title}
                        </li>
                    )}

                </ul>
            </div>
        </div>
    )
}

export default SearchBox