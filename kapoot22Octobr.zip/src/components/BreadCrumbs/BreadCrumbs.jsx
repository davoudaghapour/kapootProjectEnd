import { useEffect, useState } from 'react'
import './BreadCrumbs.css' // Code => 03
import { BsChevronLeft } from 'react-icons/bs'
import { Link, useLocation, useParams } from 'react-router-dom'
import { useSelector } from 'react-redux'

const BreadCrumbs = () => {
    let brand;
    const params = useParams()
    const location = useLocation()
    const Brands = useSelector(state => state._brand_car.Brands)
    const home_page = { title: 'صفحه اصلی', url: '/' };
    const [itemsList, setItemsList] = useState([home_page])
    const patchKey = location.pathname.split('/').filter(i => i !== '')
    
    useEffect(() => {
        switch (patchKey[0]) {
            case 'brand':
                brand = Brands.find(b => b.url == patchKey[1])
                setItemsList([home_page, {
                    title: 'لوازم یدکی ' + brand?.title,
                    url: location.pathname
                }])
                break
            case 'posters':
                brand = Brands.find(b => b.title == params.brandName.replaceAll('_', ' '))
                setItemsList([home_page,
                    {
                        title: 'لوازم یدکی ' + params.brandName.replaceAll('_', ' '),
                        url: '/brand/' + brand?.url
                    },
                    {
                        title: 'لوازم یدکی ' + params.carModel,
                        url: null
                    }])

                break
            case 'pd':
                setItemsList([home_page])
                /*
                let b = location.state.brandName || '';
                let m = location.state.carModel || ''
                setItemsList([home_page,
                    {
                        title: `لوازم یدکی ${b.replaceAll('_', ' ')} ${m}`,
                        url: `/posters/${location.state.brandName}/${location.state.carModel}`
                    },
                    {
                        title: location.state.postTitle,
                        url: null
                    }])
                    */
                break
            case 'about-us':
                setItemsList([home_page, { title: 'درباره کاپوت', url: null }])
                break
        }

    }, [location])
    console.log(itemsList)
    return (
        <nav className='container my-1'>
            <div className="location-content_03 no-scrollbar">
                {itemsList.map((item, idx) => item.url ?
                    <Link to={item.url} className="item_03" key={idx} >
                        <span>
                            {item.title}
                        </span>
                        <span className="icon_03">
                            <BsChevronLeft />
                        </span>
                    </Link>
                    :
                    <div className="item_03" key={idx} >
                        <span>
                            {item.title}
                        </span>
                        <span className="icon_03">
                            <BsChevronLeft />
                        </span>
                    </div>
                )}
            </div>
        </nav>
    )
}

export default BreadCrumbs