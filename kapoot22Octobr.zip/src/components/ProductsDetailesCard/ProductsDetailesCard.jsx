import React, { useEffect, useRef, useState } from 'react'
import { BsCartPlus, BsShieldFillCheck, BsStarFill, BsTrash3 } from 'react-icons/bs'
import { GrMapLocation } from "react-icons/gr";
import { FaArrowRightLong } from 'react-icons/fa6';
import { LikeButton, ShareButton } from '../ToggleButtons/ToggleButtons';
import { useSeparate } from '../../Hook/useNumbers';
import './ProductsDetailesCard.css' // Code => 52
import { Link } from 'react-router-dom';
import ModalContainer from '../../ModalContainer/ModalContainer';
import { useOutClicker } from '../../Hook/useOutsideClick';
import MapModal from '../MapModal/MapModal';
import { useDispatch, useSelector } from 'react-redux';
import { addUserFavorites, removeUserFavorites } from '../../redux/UserReducer/userSlice';
import CountInput from '../CounterInput/CountInput';
import { addToCart, updatteCartCount, removeFromCart } from '../../redux/CartReducer/CartSlice';

const ProductsDetailesCard = ({ category, id, price, title, userID }) => {
    const dispatch = useDispatch()
    const cartBtn_ref = useRef(null)
    const User_Favorites = useSelector(state => state.userInfo.favorites)//favorites
    const isFavorite = User_Favorites.find(i => i == id) ? true : false;
    const User_Cart = useSelector(state => state.cart)//Cart
    const postInCart = User_Cart.find(item => item.postId == id);
    const [cartCounter, setCartCounter] = useState(postInCart ? postInCart.count : null)
    const [showContactInfo, setShowContactInfo] = useState(false)
    const [showMapModal, setShowMapModal] = useState(false)

    const [contactModal_ref, contactCloseAction] = useOutClicker(setShowContactInfo)
    const [mapModal_ref, mapCloseAction] = useOutClicker(setShowMapModal)

    const addToFavorites = (e, payload) => {
        payload ? dispatch(addUserFavorites(id)) : dispatch(removeUserFavorites(id));
    }

    const shareHandle = () => {
        navigator.share({
            title: title,
            url: window.location.href,
            text: `${title} | در کاپوت`
        })
    }

    const openMap = () => {
        setShowMapModal(!showMapModal)
    }

    const showContactModal = () => {
        setShowContactInfo(!showContactInfo)
    }

    //__________________ Handel addto Cart actions... ________________
    useEffect(() => {
        if (cartCounter) {
            cartBtn_ref.current.classList.add('flay_to_cart')
            postInCart ?
                dispatch(updatteCartCount({ id: id, value: cartCounter }))
                : dispatch(addToCart(id));
        } else {
            dispatch(removeFromCart(id))
        }
    }, [cartCounter])

    const addToCartHandel = () => {
        const cartbtn = document.getElementById('header_button:cart')
        const start_pos = {
            top: cartBtn_ref.current.getBoundingClientRect().top + 'px',
            left: cartBtn_ref.current.getBoundingClientRect().left + 'px'
        }
        const end_pos = {
            top: cartbtn.getBoundingClientRect().top + 3 + 'px',
            left: cartbtn.getBoundingClientRect().left + 10 + 'px'
        }

        cartBtn_ref.current.style.setProperty('--top-1', start_pos.top)
        cartBtn_ref.current.style.setProperty('--left-1', start_pos.left)
        cartBtn_ref.current.style.setProperty('--top-2', end_pos.top)
        cartBtn_ref.current.style.setProperty('--left-2', end_pos.left)
        cartBtn_ref.current.classList.add('flay_to_cart')

        setCartCounter(1)
    }

    const deleteFromCart = () => {
        cartBtn_ref.current.classList.remove('flay_to_cart')
        setCartCounter(null)
    }

    const counterManulInput = (p) => {
        setCartCounter(Number(p))
        console.log(p)
    }

    const counterValueHandel = (n) => {
        setCartCounter(prevent => prevent += n)
        console.log(n)
    }

    return (<>
        <div className="card detailes-card_52">
            <div className="title_52">
                <h3>
                    {title}
                </h3>
                <div className="car-info_52">
                    خودروی
                    <span> کیا  </span>
                    مدل
                    <span> فلان  </span>
                </div>
            </div>
            <div className="detaile-body_52">
                <ul className="featurs-content_52">
                    <li className="feature_52">
                        دقایقی پیش در تبریز
                    </li>
                    <li className="feature_52">
                        <span>
                            فروشنده:
                        </span>
                        <span>
                            فروشگاه کاپوت
                        </span>
                    </li>
                    <li className="feature_52">
                        <span>
                            شماره تماس فروشنده:
                        </span>
                        <span>
                            ۰۹۱۴۱۲۳۴۵۶۷
                        </span>
                    </li>
                    <li className="feature_52">
                        <span>
                            لینک سایت فروشنده:
                        </span>
                        <Link to='' target='_blank' >
                            www.kapoot.com
                        </Link>
                    </li>
                    <li className="feature_52 btn location-btn_52" onClick={openMap}>
                        <span className='icon_52 '>
                            <GrMapLocation size={20} />
                        </span>
                        <span>
                            نمایش موقعیت مکانی
                        </span>
                    </li>
                </ul>

                <ul className="featurs-content_52">
                    <li className="toggle-content_52 flex_52">
                        <div className="ratting_52 flex_52">

                            <span className='icon_52'>
                                <BsStarFill size={20} />
                            </span>
                            <span>
                                4.5
                            </span>
                        </div>
                        <div className="toggles_52 flex_52">
                            <ShareButton onShare={shareHandle} />
                            <LikeButton onClick={addToFavorites} isChecked={isFavorite} />
                        </div>
                    </li>
                    <li className="feature_52 flex_52">
                        <span>
                            <BsShieldFillCheck size={20} color='#16a34a' />
                        </span>
                        <span>
                            گارانتی سلامت فیزیکی کالا
                        </span>
                    </li>
                    <li className="feature_52">
                        <span>
                            برند تولید کننده:
                        </span>
                        <span>
                            طرح اصلی
                        </span>
                    </li>
                    <li className="feature_52">
                        <span>
                            کشور سازنده:
                        </span>
                        <span>
                            کره جنوبی
                        </span>
                    </li>
                    <li className="feature_52">
                        <span>
                            نوع دسته بندی:
                        </span>
                        <span>
                           {category}
                        </span>
                    </li>
                </ul>
            </div>

            <div className="detaile-footer_52">
                <div className="price_52">
                    {useSeparate(price)}
                    <span>تومان</span>
                </div>

                <div className="footer-butons_52">
                    <button className="btn btn-animate contact-btn_52" onClick={showContactModal}>
                        اطلاعات تماس
                    </button>

                    <Link to={''} target='_blank' className="btn btn-animate link-btn_52">
                        خرید از سایت فروشنده
                    </Link>

                    <button ref={cartBtn_ref} className="btn btn-animate cart-btn_52" onClick={addToCartHandel}>
                        <BsCartPlus size={22} />
                        <span>
                            افزودن به سبدخرید
                        </span>
                    </button>
                    {cartCounter >= 1 &&
                        <div className="cart-counter_52">
                            <CountInput
                                value={cartCounter}
                                onPluse={() => counterValueHandel(1)}
                                onMinus={() => counterValueHandel(-1)}
                                onInputValue={counterManulInput}
                            />
                            <span className="counter-trash_52" onClick={deleteFromCart}>
                                <BsTrash3 size={24} />
                            </span>
                        </div>
                    }


                </div>

            </div>
        </div>
        {showMapModal &&
            <ModalContainer onClick={mapCloseAction}>
                <div ref={mapModal_ref} className="map-wrapper_52">
                    <div className="map-close_52">
                        <div onClick={() => openMap(false)}>
                            <FaArrowRightLong />
                            <span> بازگشت </span>
                        </div>
                    </div>
                    <div className="map_52">
                        <MapModal markerPosition={{ lat: 38.062391953497155, lng: 46.29003524780274 }} />
                    </div>

                </div>
            </ModalContainer>
        }

        {showContactInfo &&
            <ModalContainer onClick={contactCloseAction}>
                <div ref={contactModal_ref} className="contact-card_52">
                    <div className="card-header_52">
                        <span className="h6"> اطلاعات تماس </span>
                        <span className="close-icon_52" onClick={showContactModal}> &#10006; </span>
                    </div>
                    <ul>
                        <li className="contact-item_52">
                            <span>
                                شماره تماس ۱:
                            </span>
                            <a href={`tel:+${98941}`}>
                                09141234567
                            </a>
                        </li>
                        <li className="contact-item_52">
                            <span>
                                شماره تماس ۲:
                            </span>
                            <a href={`tel:+${98941}`}>
                                09141234567
                            </a>
                        </li>

                    </ul>
                </div>
            </ModalContainer>
        }
    </>)
}

export default ProductsDetailesCard