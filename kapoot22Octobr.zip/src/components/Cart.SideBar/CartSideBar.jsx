import { useEffect, useRef, useState } from 'react'
import { FaTrashCan, FaXmark } from "react-icons/fa6";
import { useSeparate } from '../../Hook/useNumbers';
import ModalContainer from '../../ModalContainer/ModalContainer';
import { useDispatch, useSelector } from 'react-redux';
import { closeCartMenu, removeFromCart, updatteCartCount } from '../../redux/CartReducer/CartSlice';
import { useOutClicker } from '../../Hook/useOutsideClick';
import { Link } from 'react-router-dom';
import CountInput from '../CounterInput/CountInput';
import './CartSideBar.css' // Code => 06


const CartSideBar = ({ }) => {
    const [Cart_ref, clickAction] = useOutClicker(closeSideBar)
    const dispatch = useDispatch()
    /////// Data - Get list of cart items from redux /////////////////
    const cartList = useSelector(state => state.cart)
    /////// Data - Get list of Ads from redux or api /////////////////
    const postsList = useSelector(state => state.posts)

    const cartItems = cartList.map(item => {
        return {
            ...postsList.find(post => post.id == item.postId),
            countInCart: item.count
        }
    });

    const deleteFromCart = (itemId) => {
        dispatch(removeFromCart(itemId))
    }

    const counterManulInput = (itemId, p) => {
        // کنترل تعداد سفارش یک آیتم به صورت دلخواه
        dispatch(updatteCartCount({ id: itemId, value: Number(p) }))
    }

    const counterValueHandel = (itemId, n) => {
        // افزایش یا کاهش تعداد سفارش یک آیتم به صورت تکی
        const ci = cartList.find(item => item.postId == itemId)
        dispatch(updatteCartCount({ id: itemId, value: ci.count + n }))
    }

    function closeSideBar() {
        Cart_ref.current.style.animationDuration = '.2s';
        Cart_ref.current.style.animationName = 'close-animation';
        setTimeout(() => {
            dispatch(closeCartMenu())
        }, 200);
    }

    return (
        <ModalContainer onClick={clickAction}>
            <aside ref={Cart_ref} className='cart_06 open_06'>
                <div className="cart-content_06">
                    <div className="cart-header_06">
                        <span className="close-icon_06" onClick={closeSideBar}>
                            <FaXmark size={'100%'} />
                        </span>
                        <span className="h5">
                            سبد خرید
                        </span>
                    </div>
                    <ul className="cart-list_06 no-scrollbar">
                        {cartItems.map(post =>

                            <li key={post.id} className="cart-item_06">
                                <div className="image_06">
                                    <img src="/public/Images/no-image.webp" alt={post.title} />
                                </div>
                                <div className="body_06">
                                    <span className="line-limit-1">
                                        {post.title}
                                    </span>
                                    <span className="price_06">
                                        {useSeparate(post.price)}
                                        <small>تومان</small>
                                    </span>
                                    <div className="counter-box_06">
                                        <CountInput
                                            className="counter_06"
                                            value={post.countInCart}
                                            onPluse={() => counterValueHandel(post.id, 1)}
                                            onMinus={() => counterValueHandel(post.id, -1)}
                                            onInputValue={(p) => counterManulInput(post.id, p)}
                                        />
                                        <span className="delete-btn_06" onClick={() => deleteFromCart(post.id)}>
                                            <FaTrashCan size={20} />
                                        </span>
                                    </div>
                                </div>
                            </li>
                        )}

                    </ul>
                    <div className="cart-button_06">
                        <Link to={'/cart'} className="btn btn-animate" onClick={closeSideBar}>
                            سبد خرید
                        </Link>
                    </div>
                </div>
            </aside>
        </ModalContainer>
    )
}

export default CartSideBar