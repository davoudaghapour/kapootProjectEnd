import './Advertising.css' // Code 004

const Advertising = ({ row, image_1, image_2 }) => {
    return (
        <aside className='advertising_004' style={{ gridRow: row }}>
            <div className="ads_004">
                <img src={image_1} alt="" />
            </div>
            <div className="ads_004">
                <img src={image_2} alt="" />
            </div>
        </aside>
    )
}

export default Advertising