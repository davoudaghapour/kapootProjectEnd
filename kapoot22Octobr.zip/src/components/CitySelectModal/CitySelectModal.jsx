import { useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import ModalContainer from '../../ModalContainer/ModalContainer'
import './CitySelectModal.css' // Code => 07
import { BsChevronLeft } from 'react-icons/bs'
import { closeCityModal, setCitiesList } from '../../redux/CityReducer/CitySlice'
import { useOutClicker } from '../../Hook/useOutsideClick'
////////// Local Data (json file) /////////////
import Provinces_Json from '../../assets/Data/provinces.json'

const CitySelectModal = () => {
    const [modal_ref, outClicker] = useOutClicker(closeHandler)
    const dispatch = useDispatch()
    const Provinces_Cities_list = useRef(Provinces_Json)//=> data from JSON file (local)
    let provinces = useRef([])
    const userCities = useSelector(state => state.citiesList)//=> Get from Redux
    const [selectList, setSelectList] = useState(userCities)

    /////// Create list of ostan_ha /////////
    provinces.current = Provinces_Json.filter(item => item.FID == 0);

    const openDropDown = (e) => {
        e.currentTarget.parentElement.classList.toggle('active-item_07')
    }

    const selectCity = (e, c) => {
        e.target.checked ?
            setSelectList(prevent => [...prevent, c])
            : removeSelection(c)
    }

    const selectCityAll = (e, ostanID) => {
        let cities = Provinces_Cities_list.current.filter(i => i.FID == ostanID).map(city => city.title)
        e.target.checked ?
            setSelectList([...cities])
            : setSelectList(selectList.filter(i => !cities.includes(i)))
    }

    const removeSelection = (item) => {
        item == 'all' ? setSelectList([])
            : setSelectList(selectList.filter(i => i != item))
    }

    const confirmSelection = () => {
        dispatch(setCitiesList(selectList))
        closeHandler()
    }

    function closeHandler() {
        setTimeout(() => dispatch(closeCityModal()), 310)
        modal_ref.current.classList.toggle('close-it_07')
    }

    //////////////// Create list of cities for every provinve ///////////
    const CityContainer = ({ province }) => {
        const citiesList = Provinces_Cities_list.current.filter(item => item.FID == province.id)

        return (<>
            <ul className="list-shahrha_07">
                <li className="city-item_07">
                    <input type="checkbox" id={`check_AC${province.id}`} checked={citiesList.every(i => selectList.includes(i.title))} onChange={(e) => selectCityAll(e, province.id)} />
                    <label htmlFor={`check_AC${province.id}`}> همه شهر‌های {province.title} </label>
                </li>
                {citiesList.map(city =>
                    <li key={city.id} className="city-item_07">
                        <input
                            type="checkbox"
                            id={`check:C:${city.id}`}
                            checked={selectList.includes(city.title)}
                            onChange={(e) => selectCity(e, city.title)}
                        />
                        <label htmlFor={`check:C:${city.id}`}> {city.title} </label>
                    </li>
                )}

            </ul>
        </>)
    };
    ////////////////////////////////////////////////////////////////////

    return (
        <>
            <ModalContainer onClick={outClicker}>
                <div ref={modal_ref} className="card modal_07">
                    <div className="modal-header">
                        <span className="h5">
                            انتخاب شهر
                        </span>
                        <div>
                            {selectList.length == 0 ?
                                <span className="empty-list_07">
                                    حداقل یک شهر انتخاب کنید
                                </span>
                                :
                                <ul className="select-list_07">
                                    {selectList.slice(0, 3).map((item, idx) =>

                                        <li key={idx} className="selected-item_07">
                                            <span>
                                                {item}
                                            </span>
                                            <span className="remove-icon_07" onClick={() => removeSelection(item)}>
                                                &#10006;
                                            </span>
                                        </li>

                                    )}
                                    {selectList.length > 3 &&
                                        <li className="selected-item_07">
                                            <span>
                                                و {selectList.length - 3} شهر دیگر
                                            </span>
                                            <span className="remove-icon_07" onClick={() => removeSelection('all')}>
                                                &#10006;
                                            </span>
                                        </li>
                                    }

                                </ul>
                            }
                        </div>
                    </div>
                    <div className="modal-containert_07">
                        <ul className="list-ostanha_07">
                            {provinces.current.map(item =>
                                <li key={item.id}>
                                    <div className="ostan-item_07" onClick={openDropDown}>
                                        <span> {item.title} </span>
                                        <span className="arrow-icon_07"> <BsChevronLeft /> </span>
                                    </div>

                                    <CityContainer province={item} />

                                </li>

                            )}
                        </ul>
                    </div>
                    <div className="modal-buttons_07">
                        <button className="btn btn-animate ok-btn_07" onClick={confirmSelection} >
                            تایید
                        </button>
                        <button className="btn cancel-btn_07" onClick={closeHandler}>
                            انصراف
                        </button>
                    </div>
                </div>
            </ModalContainer>
        </>
    )
}

export default CitySelectModal