import './Header.css' // Code => 01
import { Link, useMatch, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { BsPlusCircleDotted, BsGeoAlt, BsPersonCheckFill, BsPersonCircle, BsCart3 } from "react-icons/bs";
import SearchBox from '../SearchBox/SearchBox';
import Navigation from '../Navigation/Navigation';
import CartSideBar from '../Cart.SideBar/CartSideBar';
import { openCityModal } from '../../redux/CityReducer/CitySlice';
import { openCartMenu } from '../../redux/CartReducer/CartSlice';
import CitySelectModal from '../CitySelectModal/CitySelectModal';

const Header = () => {
    const dashboardRout = useMatch('/userdashbord/*')
    const navigate = useNavigate()
    const dispatch = useDispatch()

    /////////// Load Data from Redux... ////////
    const siteInfo = useSelector(state => state._siteInfo)
   // const siteStories = useSelector(state => state.)

    const isLogin = useSelector(state => state.userInfo.isLogin)
    const Cities_List = useSelector(state => state.citiesList)
    const cart_length = useSelector(state => state.cart.length)
    //******** State for open/close a moadal **********//
    const cityModalStatus = useSelector(state => state.citySolector.value)
    const cart_sideMenu = useSelector(state => state.cartSideMenuStatus.value)
    //////////////////////////////////////////

    const profileClickHandler = () => {
        navigate('/userdashbord/profile')
    }
    const addNewPostClick = () => {
        navigate('/new-post')
    }
    const openCartSideMenu = () => {
        dispatch(openCartMenu())
    }

    const citySelectorOpen = () => {
        dispatch(openCityModal())
    }

    console.log("site name is : "+ siteInfo?.SiteName)
    return (
        <>
            <header className={`Header_01 ${dashboardRout ? 'header_hide' : ''}`}>
                <div className="container header_container">
                    <div className="header-logo_01">
                        <Link to='/' >
                            <img src="/logo.webp" alt={siteInfo?.SiteName}  />
                        </Link>
                    </div>

                    <SearchBox className='search-box_01' />

                    <div className="header-button-group">
                        <div className="button_01" onClick={profileClickHandler} >
                            {isLogin ? <>
                                <BsPersonCheckFill size={22} />
                                <span className='title_01'>
                                    {`${siteInfo.SiteName} من`}
                                </span>

                            </> : <>
                                <BsPersonCircle size={22} />
                                <span className='title_01'>
                                    ورود
                                </span>
                            </>}

                        </div>
                        <div className="button_01" onClick={addNewPostClick} >
                            <BsPlusCircleDotted size={22} />
                            <span className='title_01'>
                                ثبت آگهی
                            </span>
                        </div>
                        <div id='header_button:cart' className="button_01" onClick={openCartSideMenu} >
                            <BsCart3 size={22} />
                            <span className='counter_01'>
                                {cart_length}
                            </span>
                        </div>
                        <div className="button_01 city-selector_01" onClick={citySelectorOpen} >
                            <BsGeoAlt size={22} />
                            <span className={`title_01 ${Cities_List.length != 0 && 'bg-red_01'}`}>
                                {Cities_List.length == 0 ? ' انتخاب شهر' :
                                    Cities_List.length > 1 ? `${Cities_List.length}   تا شهر` : Cities_List[0]
                                }
                            </span>
                        </div>
                    </div>
                </div>
                <Navigation showBaseMenu={true}/>
            </header>

            {cityModalStatus && <CitySelectModal />}
            {cart_sideMenu && <CartSideBar />}

        </>
    )
}

export default Header