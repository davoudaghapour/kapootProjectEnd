import { useRef } from 'react'
import './BaseMenu.css' // Code => 21
import SubMenu from './SubMenu'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'

const BaseMenu = () => {
  const menu_ref = useRef(null)
  let baseData = useRef([])
  let menuData = useRef([])
  const MENU_ID = 1;
  const BRANDE_ID = 8;

  ////// Get Brandes list and siteMenu items from redux //////////
  const brands = useSelector(state => state._brand_car?.Brands)
  const siteMenuItems = useSelector(state => state._siteMenu)

  baseData.current = [
    ...siteMenuItems.filter(item => item.parentID != 0),
    ...brands.map(item => ({ ...item, id: siteMenuItems.length + item.id, parentID: BRANDE_ID }))
  ]

  menuData.current = [
    ...baseData.current.filter(item => item.parentID == MENU_ID)
  ]

  const createSubMenuItemList = (n) => {
    let list = baseData.current.filter(item => item.parentID == n)

    switch (n) {
      case 8:   //========> id of "برند خودرو"
        list = list.map(item => ({ ...item, urlKey: 'brand/' }))
        break
      case 9:   //========> id of "لوازم مصرفی"
        list = list.map(item => ({ ...item, urlKey: '#/' })) // فعلا روتی  برای این آیتم تعریف نشده
        break
      case 10:  //========> id of "اکسسوری خودرو"
        list = list.map(item => ({ ...item, urlKey: '#/' })) // فعلا روتی  برای این آیتم تعریف نشده
        break
      case 11:  //========> id of "لوازم جانبی خودرو"
        list = list.map(item => ({ ...item, urlKey: '#/' })) // فعلا روتی  برای این آیتم تعریف نشده
        break
      case 11:  //========> id of "نگهداری خودرو"
        list = list.map(item => ({ ...item, urlKey: '#/' })) // فعلا روتی  برای این آیتم تعریف نشده
        break
    }
    return list
  };


  const onHoverHandler = (e) => {
    for (let menuItem of menu_ref.current.children) {
      menuItem.classList.remove('active_21')
    }
    e.target.parentElement.classList.add('active_21')
  }

  return (
    <div className='menu_container_21'>
      <ul ref={menu_ref} className='content_21'>
        {menuData.current.map((mi, idx) =>
          <li key={mi.id} className={`menu-item_21 ${idx == 0 && 'active_21'}`}>
            <Link to='#Brands_Section' className='title_21' onMouseOver={onHoverHandler}>
              {mi.title}
            </Link>
            <SubMenu list={createSubMenuItemList(mi.id)} />
          </li>
        )}
      </ul>
    </div>
  )
}

export default BaseMenu



