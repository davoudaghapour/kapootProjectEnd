import { Link } from 'react-router-dom';
import { useHorizontalScroll } from '../../Hook/useHorizontalScroll';

const SubMenu = ({ list }) => {
    const container_ref = useHorizontalScroll()
    return (
        <ul ref={container_ref} className="sub-menu_21">
            {list.map((item, idx) =>
                <li key={`sm:${item.id}.${idx}`} className="sub-item_21">
                    <Link to={item.urlKey + item.url}>
                        {item.title} 
                    </Link>
                </li>
            )}
        </ul>
    )
}

export default SubMenu