import { useRef } from 'react'
import BaseMenu from '../Navigation.BaseMenu/BaseMenu'
import MobileNavBar from './MobileNavBar/MobileNavBar'
import { TfiMenuAlt } from "react-icons/tfi";
import './Navigation.css' // Code => 02
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';

const Navigation = ({ showBaseMenu, mobileMode }) => {
    const MENU_ID = 0;
    let navItemList = useRef([])
    ////////////  Get SiteMenu from redux /////////////////
    const siteMenuItems = useSelector(state => state._siteMenu)

    //////////// Get navigation items from SiteMenu /////////////////
    navItemList.current = siteMenuItems.filter(item => item.parentID == MENU_ID)
    const baseManu = navItemList.current.shift() //=> frist item of list (منو اصلی)

    return (
        <nav>
            <div className={"container navbar-content"}>

                {showBaseMenu && <BaseMenuButton item={baseManu} />}

                <ul className={`navbar_02 ${mobileMode ? 'nb-mobile_02' : ''}`}>

                    {navItemList.current.map(item =>
                        <li key={`Nav:${item.id}`} className="nav_link_02">
                            <Link to={item.url}>

                                <img src={item.img} alt={item.title} />

                                <span>
                                    {item.title}
                                </span>
                            </Link>
                        </li>
                    )}
                </ul>

            </div>
            <MobileNavBar />
        </nav>
    )
}

export default Navigation

function BaseMenuButton({ item }) {
    return (
        <div className="menu-button_02">
            <div className="btn btn-primary btn-animate">
                <TfiMenuAlt size={20} />
                <span>
                    {item.title}
                </span>
            </div>
            <BaseMenu />
        </div>
    )
}