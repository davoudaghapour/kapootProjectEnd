import { Outlet } from 'react-router-dom'
import { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import axios from 'axios'
import './App.css'
import Footer from './components/Footer/Footer'
import Header from './components/Header/Header'
import WellcomePage from './Pages/WellcomePage/WellcomePage'
import Toast from './components/Toast/Toast'
import Loading from './components/Loading/Loading'
import { getPosts } from './assets/Data/postGenerator'
import { setPosts } from './redux/PostsReducer/PostsSlice'
import { setUserInfo } from './redux/UserReducer/userSlice'
import { setSiteInfo } from './redux/SiteInfoReducer/SiteInfoSlice'
import { setSiteMenu } from './redux/SiteMenuReducer/SiteMenuSlice'
import { setStories } from './redux/StoriesRecucer/storiesSlice'

import { setCars, setBrands } from './redux/Brands.Cars_Reducer/BrandSlice'
//////////////// Get data from local Json file //////////////
import SiteMenuJson from './assets/Data/Menu.json'
import BrandesJson from './assets/Data/Brands.json'
import CarsJson from './assets/Data/Cars.json'


function App() {
    const dispatch = useDispatch()
    const [connection, setConnection] = useState({ on: false, off: false })
    const [isPendding, setIsPendding] = useState(true)
    const [isLoaded, setIsLoaded] = useState(false)
    const API_BASE_URL = "http://localhost:3000";
    let check = useRef({})

    const dataCheckHandel = () => {
        if (!isLoaded) {
            const keies = Object.values(check.current)
            if (keies.length > 0 && keies.every(item => item)) setIsLoaded(true)
        }
    };

    /*
        const { _siteInfo, _siteMenu, _brand_car } = useSelector(state => state)
        useEffect(() => {
            //console.log(Object.values(check.current))
            if (
                _siteInfo && _siteMenu.length > 0 &&
                _brand_car.Brands.length > 0 && _brand_car.Cars.length > 0
            ) setIsLoaded(true)
        }, [_siteInfo, _siteMenu, _brand_car])
    */


    useEffect(() => {
        window.addEventListener('online', () => setConnection({ on: true, off: false }))
        window.addEventListener('offline', () => setConnection({ on: false, off: true }))
        // دریافت لیست تمام آگهی‌ها از سرور و ذخیره در ریداکس
        const postsList = getPosts(150)
        dispatch(setPosts(postsList))
    }, [])

    ////////////////////// Data ////////////////////////////
    useEffect(() => {

        //********** Load SiteInfo **************//
        const getSiteInfo_API = async () => {
            const url = `${API_BASE_URL}/siteinfo`;
            axios(url, {
                mode: "cors",
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            axios.get(url).then(result => result.data)
                .then(data => {  // => work with data ...
                    ///// Set result in redux ////////
                    check.current['site_infoes'] = true;
                    dispatch(setSiteInfo(data[0]))
                })
                .catch(error => {
                    check.current['site_infoes'] = false;
                    console.log(error)
                })

            //return () => dataCheckHandel() // => بررسی میکند تا ببیند تمام داده های ضروری در ریداکس ذخیره شده یا نه
        };
        //**************************************//

        //********** Load SiteMenu items **************//
        const getSiteMenu_API = async () => {
            const url = `${API_BASE_URL}/sitemenu`;
            axios(url, {
                mode: "cors",
                headers: {
                    'Content-Type': 'application/json',
                }
            })

            try {

                const result = await axios.get(url);
                check.current['site_menu'] = true;
                ///// Set result in redux ////////
                dispatch(setSiteMenu(result.data))

            } catch (error) {

                if (error.response) {
                    //  The client was given an error response (5xx ,4xx)
                    console.log(error.response)
                } else if (error.request) {
                    // The client never received a response, and the request was never left
                    console.log(error.request)
                } else {
                    // Anything else
                    console.log('Error : ', error)
                }
                check.current['site_menu'] = false;

            }

            //return () => dataCheckHandel() // => بررسی میکند تا ببیند تمام داده های ضروری در ریداکس ذخیره شده یا نه
        };
        //**************************************//
          //********** Load stories list  **************//
          const getStories_API = async () => {
            const url = `${API_BASE_URL}/stories`;
            axios(url, {
                mode: "cors",
                headers: {
                    'Content-Type': 'application/json',
                }
            })

            try {

                const result = await axios.get(url);
                check.current['site_stories'] = true;
                ///// Set result in redux ////////
                dispatch(setStories(result.data))

            } catch (error) {

                if (error.response) {
                    //  The client was given an error response (5xx ,4xx)
                    console.log(error.response)
                } else if (error.request) {
                    // The client never received a response, and the request was never left
                    console.log(error.request)
                } else {
                    // Anything else
                    console.log('Error : ', error)
                }
                check.current['site_menu'] = false;

            }

            //return () => dataCheckHandel() // => بررسی میکند تا ببیند تمام داده های ضروری در ریداکس ذخیره شده یا نه
        };
        //**************************************//


        //********** Load Brands and Cars **************//
        const Brand_Result = BrandesJson
        const Car_Result = CarsJson

        check.current['bc'] = true
        dispatch(setBrands(Brand_Result))
        dispatch(setCars(Car_Result))

        const getBrandsAndCars_API = async () => {
            const url = `${API_BASE_URL}/brands_cars`;
            axios(url, {
                mode: "cors",
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            axios.get(url).then(result => result.data)
                .then(data => {  // => work with data ...
                    ///// Set result in redux ////////
                    check.current['brand'] = true;
                    dispatch(setBrands(data[0]))
                    dispatch(setCars(data[1]))
                })
                .catch(error => {
                    check.current['brand'] = false;
                    console.log(error)
                })

            //return () => dataCheckHandel() // => بررسی میکند تا ببیند تمام داده های ضروری در ریداکس ذخیره شده یا نه
        };

        //**************************************//

        //********** Load UserInfo if he is logedin before *************//
        const TOKAN = localStorage.getItem('tokan')
        if (TOKAN) {
            dispatch(setUserInfo({ isLogin: true, tokan: TOKAN }))
        }

        ////////  get users list from api //////
        const getUserInfo_API = async () => {
            const url = `${API_BASE_URL}/users`;
            axios(url, {
                mode: "cors",
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            axios.get(url).then(result => result.data)
                .then(data => {  // => work with data ...
                    ///// Set result in redux ////////
                    dispatch(setUserInfo(data[0]))
                })
                .catch(error => {
                    console.log(error)
                })

            //return () => dataCheckHandel() // => بررسی میکند تا ببیند تمام داده های ضروری در ریداکس ذخیره شده یا نه
        };

        //**********************************************************//

        const send_API_Requests = async () => {
            await getSiteInfo_API()
            await getSiteMenu_API()
            await getUserInfo_API()
            //awite getBrandsAndCars_API()

            // After get data from api set isLoaded to true   
            setIsLoaded(true)
        };
        send_API_Requests()

    }, [])

    //{isPendding && <WellcomePage preview={!isLoaded} closeHandler={() => setIsPendding(false)} />}
    return (<>

        {isLoaded && <>
            <Header />
            <Outlet />
            <Footer />
            {connection.on && <Toast type='success' header=' ' msg='اتصال اینترنت برقرار شد :)' timer={3} onClose={() => setConnection({ on: false, off: false })} />}
            {connection.off && <Toast type='warning' header=' ' msg='اتصال اینترنت قطع شد :(' timer={3} onClose={() => setConnection({ on: false, off: false })} />}
        </>}


    </>)
}

export default App