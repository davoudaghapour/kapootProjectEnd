import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const SiteMenu_db = db.define("menues", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    title: {
        type: DataTypes.STRING
    },
    img: {
        type: DataTypes.STRING
    },
    parentID: {
        type: DataTypes.INTEGER
    },
    url: {
        type: DataTypes.STRING
    }

});



export default SiteMenu_db;





