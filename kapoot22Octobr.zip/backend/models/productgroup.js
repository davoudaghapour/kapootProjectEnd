import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const productgroup = db.define("productgroup", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    ProductGroupTItle: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },
    ParentID: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    },
 
});



export default productgroup;





