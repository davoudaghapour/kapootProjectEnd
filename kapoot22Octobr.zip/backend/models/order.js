import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const order = db.define("order", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },

    userID: {
        type: DataTypes.INTEGER,
     //   primaryKey: true
    },
    Sum: {
        type: DataTypes.INTEGER,
     //   primaryKey: true
    },
    CreatFactor: {
        type: DataTypes.DATE
    },
    IsSucsess: {
        type: DataTypes.BIT
    }
  
});



export default order;





