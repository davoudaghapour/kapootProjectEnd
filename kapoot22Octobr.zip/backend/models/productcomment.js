import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const productcomment = db.define("productcomment", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    userID: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },

    
    Comment: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },
    DateTIme: {
        type: DataTypes.DATE,
        //   primaryKey: true
    },

    
    Visit: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    },

    productID: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    },
    email: {
        type: DataTypes.STRING,
        //   primaryKey: true
    } 

 

});



export default productcomment;





