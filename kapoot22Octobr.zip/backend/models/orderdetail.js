import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const orderdetail = db.define("orderdetail", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },

    OrderID: {
        type: DataTypes.INTEGER,
     //   primaryKey: true
    },

    ProductTitle: {
        type: DataTypes.STRING,
     //   primaryKey: true
    },
    ImgName: {
        type: DataTypes.STRING,
     //   primaryKey: true
    },
    ProductPrice: {
        type: DataTypes.DOUBLE,
     //   primaryKey: true
    } 
  
});



export default orderdetail;





