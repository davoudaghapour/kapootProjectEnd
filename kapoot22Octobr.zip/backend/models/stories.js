import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const Stories = db.define("stories", {
    
 
    id: {
        type: DataTypes.INTEGER,
        primaryKey:true

    },
    title: {
        type: DataTypes.STRING

    },
    userId: {
        type: DataTypes.INTEGER

    },
    registerDate: {
        type: DataTypes.DATE

    },
    link: {
        type: DataTypes.STRING

    } ,
    status: {
        type: DataTypes.INTEGER

    } 


});



export default Stories;





