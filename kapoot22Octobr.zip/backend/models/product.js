import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;


const product = db.define("product", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    ProductShenase: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },
    ProductGroupID: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    },

    
    Visit: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    },

    ProductName: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },
    Price: {
        type: DataTypes.DOUBLE,
        //   primaryKey: true
    },
    OldPrice: {
        type: DataTypes.DOUBLE,
        //   primaryKey: true
    },

    mojud: {
        type: DataTypes.BIT,
        //   primaryKey: true
    },
    BrandID: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    },

    ShortDiscrib: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },
    CreateTime: {
        type: DataTypes.DATE,
        //   primaryKey: true
    },
    fulldesc: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },

    image: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },


    status: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    },

    forushgah: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    },
});



export default product;





