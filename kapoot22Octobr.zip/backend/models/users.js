import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const Users = db.define("users", {
    
 
    id: {
        type: DataTypes.INTEGER,
        primaryKey:true
        
    },
    userName: {
        type: DataTypes.STRING

    },
    Password: {

        type: DataTypes.INTEGER
    },
    name: {
        type: DataTypes.STRING

    },
    family: {
        type: DataTypes.STRING

    },
    email: {

        type: DataTypes.INTEGER
    },
    phoneNumber: {
        type: DataTypes.STRING

    },
    regisreDate: {
        type: DataTypes.STRING

    },
    status: {

        type: DataTypes.INTEGER
    },
    rule: {
        type: DataTypes.INTEGER

    },
    bio: {
        type: DataTypes.STRING

    },
    userImg: {

        type: DataTypes.STRING
    },
    rememberMe: {
        type: DataTypes.INTEGER

    }


});



export default Users;





