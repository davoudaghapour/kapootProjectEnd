import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const productdetail = db.define("productdetail", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    ProductID: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    },
    ProductDetailTItle: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },

    
    ProductDetailText: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },
 
});



export default productdetail;





