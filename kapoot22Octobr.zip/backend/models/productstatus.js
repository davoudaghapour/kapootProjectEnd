import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const productstatus = db.define("productstatus", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    title: {
        type: DataTypes.STRING,
        //   primaryKey: true
    } 

});



export default productstatus;





