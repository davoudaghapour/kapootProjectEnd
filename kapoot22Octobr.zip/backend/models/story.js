import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const story = db.define("story", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    name: {
        type: DataTypes.STRING,
        //   primaryKey: true
    } ,
    registerdate: {
        type: DataTypes.DATE,
        //   primaryKey: true
    } 


});



export default story;





