import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const productimage = db.define("productimage", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    title: {
        type: DataTypes.STRING,
        //   primaryKey: true
    },
    productId: {
        type: DataTypes.INTEGER,
        //   primaryKey: true
    } 
});



export default productimage;





