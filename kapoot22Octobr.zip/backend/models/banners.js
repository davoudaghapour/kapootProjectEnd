import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const banners = db.define("banners", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    ImageName: {
        type: DataTypes.STRING
    },
    ImageLink: {
        type: DataTypes.STRING
    } ,
    status: {
        type: DataTypes.INTEGER,
        primaryKey: true
    }
});



export default banners;





