import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const SiteMenu_db = db.define("brand", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    brandName: {
        type: DataTypes.STRING
    },
    brandImg: {
        type: DataTypes.STRING
    },
    brandLink: {
        type: DataTypes.STRING
    },
    parentID: {
        type: DataTypes.INTEGER
    },

});



export default SiteMenu_db;





