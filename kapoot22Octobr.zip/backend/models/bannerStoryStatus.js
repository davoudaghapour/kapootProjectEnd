import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const bannerStoryStatus = db.define("bannerStoryStatus", {

    id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    title: {
        type: DataTypes.STRING,
        //   primaryKey: true
    } 

});



export default bannerStoryStatus;





