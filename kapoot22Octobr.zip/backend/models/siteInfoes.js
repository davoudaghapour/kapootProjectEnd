import { Sequelize } from "sequelize";
import db from "../config/database.js";



const { DataTypes } = Sequelize;



const SiteInfo = db.define("siteinfoes", {
    
 
    SiteInfoID: {
        type: DataTypes.INTEGER,
        primaryKey:true

    },
    SiteName: {
        type: DataTypes.STRING

    },
    SiteShortDisc: {
        type: DataTypes.STRING

    },
    SiteDiscribtion: {
        type: DataTypes.STRING

    },
    AboutUS: {
        type: DataTypes.STRING

    },
    Tell1: {
        type: DataTypes.STRING

    },
    Tell2: {
        type: DataTypes.STRING

    },
    Tell3: {
        type: DataTypes.STRING

    },
    Tell5: {
        type: DataTypes.STRING

    },
    Email: {
        type: DataTypes.STRING

    },
    SiteLog: {
        type: DataTypes.STRING

    },
    SiteRouls: {
        type: DataTypes.STRING

    },
    Address: {
        type: DataTypes.STRING

    },
    


});



export default SiteInfo;





