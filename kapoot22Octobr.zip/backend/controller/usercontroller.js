import { DATE, Sequelize } from "sequelize";
import Users from "../models/users.js";
import path from "path"
import { match } from "assert";






export const getAllUser = async (req, res) => {
    try {
        const users = await Users.findAll({});
        res.json(users);
    } catch (error) {
        console.log(error)
    }
}

export const register = async (req, res) => {

    /////////////sample/////////////////////
    // Create a new user
    const { name, Password, phoneNumber } = req.body;
    console.log(name, Password, phoneNumber);

    try {
        const found = await Users.findOne({ where: { phoneNumber: phoneNumber } })
        //  res.json(found)


        if (found) {
            return res.json("شماره قبلا ثبت شده")
        }

        await Users.create({
            name: name,
            Password: Password,
            phoneNumber: phoneNumber


        })
        res.json({ message: "register is success" })


    } catch (error) {
        console.log("user insert faild")
    }

    /////////////////////////////////


    //  const q = "INSERT INTO users (`name`, `family`, `username`) VALUES (?)";
    //  const v = [
    //      req.body.name,
    //     req.body.family,
    //     req.body.username
    //  ]
    // db.query(q, [v], (err, data) => {
    //     if (err) return res.json(err)
    //     return res.json(data)
    // })

}
 
export const login = async (req, res) => {

    /////////////sample/////////////////////
    // Create a new user
    const { Password, phoneNumber } = req.body;
    console.log(Password, phoneNumber);

    try {
        const found = await Users.findOne({ where: { phoneNumber: phoneNumber } })
        //  res.json(found)


        if (found) {
            // return res.json(found.Password)

            if (found.Password == Password) {
                // res.json("login is success")

                return res.json(found.id)

            } else {

                return res.json("number or pass is increpted")
            }

        } else {

            return res.json("کاربر وجود ندارد")

        }


    } catch (error) {
        console.log("کاربر وجود ندارد")
    }
}

 
export const delUser = async (req, res) => {

    /////////////sample/////////////////////
    // Create a new user
    const { Password, phoneNumber } = req.body;
    console.log(Password, phoneNumber);
    //  res.json(" del user")

    const user = await Users.findOne({ where: { id: req.params.id } })
    // res.json(" del user")
    if (!user) {
        return res.json("کاربر وجود ندارد")
    }

    try {
        // return res.json(found.Password)
        await Users.destroy({
            where: {
                id: req.params.id

            }

        })

        res.json("کاربر حذف شد")



    } catch (error) {
        console.log("کاربر وجود ندارد")
    }
}
 
export const getUserById = async (req, res) => {

    try {
        const user = await Users.findOne({ where: { id: req.params.id } })
        if (!user) {
            res.json("کاربر وجود ندارد")
          //  return res.json(req.params.id)

        }
        res.json(user);

    } catch (error) {
         console.log("کاربر وجود ندارد")
      //  res.json(req.params.id)
    }


}


export const getUserByUserName = async (req, res) => {
    try {
        const user = await Users.findOne({ where: { userName: req.params.userName } })
        if (!user) {
           return  res.json("کاربر وجود ندارد")
 
        }
        res.json(user);

    } catch (error) {
      console.log("کاربر وجود ندارد")
      //  res.json(req.params.id)
    }


}

export const getUserByPhonNumber = async (req, res) => {
    try {
        const user = await Users.findOne({ where: { phoneNumber: req.params.phoneNumber } })
        if (!user) {
         return     res.json("کاربر وجود ندارد")
        //  res.json(req.params.id)

        }
        res.json(user);

    } catch (error) {
      console.log("کاربر وجود ندارد")
      //  res.json(req.params.id)
    }


}


 

export const updateUser = async (req, res) => {

    /////////////sample/////////////////////

    const { userName, Password, name, family, email, phoneNumber, regisreDate, status, rule,
        bio, userImg, rememberMe
    } = req.body;

    //const{}=req.body;
    //console.log(name, Password, phoneNumber);
    //  res.json(req.body.id)



    //const { } = req.body;
    try {

        const _user = await Users.findOne({

            where: {

                id: req.params.id
            }
        })


        /*   await Users.update({
               userName: userName,
               Password: Password,
               name: name,
               family: family,
               email: email,
               phoneNumber: phoneNumber,
               regisreDate: regisreDate,
               status: status,
               rule: rule,
               bio: bio,
               userImg: userImg,
               rememberMe: rememberMe
           }, {
               where: {
                   id: req.params.id
               }
           })
   
   */


        let filename = "";
        if (req.files === null) {

            filename = _user.userImg;

        } else {

            const _file = req.files.file;
            const _fileSize = _file.data.length;
            const ext = path.extname(_file.name);
            const dateNow = Math.round(Date.now());
            const newFileName = dateNow + ext;
            const allowtypes = ['.jpeg', '.jpg', '.png'];
            if (!allowtypes.includes(ext.toLowerCase())) {
                res.json("عکس معتبر نیست.فرمت مجاز  jpeg-jpg-png")
            }
            if (_fileSize > 10000000) {
                res.json("سایز عکس نباید بیشتر از 10 مگابایت باشد")
            }

            ////////////// irad az inja mande ///////////////////
            _file.mv(`./public/Images/${newFileName}`, (err) => {

                if (err) {
                    return res.json({ msg: err.message })

                }

            })
            ////////////// irad ta inja mande ///////////////////

            console.log(_file.name);
            console.log(ext)

        }

        res.json("user updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("user update faild")
    }


 

}
