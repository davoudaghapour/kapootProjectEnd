import { Sequelize } from "sequelize";
import product from "../models/product.js";



export const getproducts = async (req, res) => {
    try {
        const p = await product.findAll({});
        res.json(p);
    } catch (error) {
        console.log(error)
    }
}

export const addproduct = async (req, res) => {


    const { ProductShenase, ProductGroupID, Visit, ProductName,
        Price, OldPrice, mojud, BrandID, ShortDiscrib, CreateTime,
        fulldesc, image, status, forushgah } = req.body;


    try {

        console.log(req.body)
        await product.create({
            ProductShenase: ProductShenase,
            ProductGroupID: ProductGroupID,
            Visit: Visit,
            ProductName: ProductName,
            Price: Price,
            OldPrice: OldPrice,
            mojud: mojud,
            BrandID: BrandID,
            ShortDiscrib: ShortDiscrib,
            CreateTime: CreateTime,
            fulldesc: fulldesc,
            image: image,
            status: status,
            forushgah: forushgah,

        })
        res.json({ message: "product added success" })
    } catch (error) {
        console.log("product added faild")
    }
}

export const getActiveproduct = async (req, res) => {
    try {
        const st = await product.findAll({
            where: {
                status: 1
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const getMojudproduct = async (req, res) => {
    try {
        const st = await product.findAll({
            where: {
                mojud: true
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}
export const getproductByBrandID = async (req, res) => {
    try {
        const st = await product.findAll({
            where: {
                BrandID: req.params.BrandID
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}
export const getproductByforushgahID = async (req, res) => {
    try {
        const st = await product.findAll({
            where: {
                forushgah: req.params.forushgah
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const getproductByShenase = async (req, res) => {
    try {
        const st = await product.findAll({
            where: {
                ProductShenase: req.params.ProductShenase
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}
export const getproductByGroupID = async (req, res) => {
    try {
        const st = await product.findAll({
            where: {
                ProductGroupID: req.params.ProductGroupID
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const deleteproduct = async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await product.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("محصول وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await product.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("محصول حذف شد")
    } catch (error) {
        console.log("محصول وجود ندارد")
    }
}
export const updateproduct = async (req, res) => {
    const { ProductShenase, ProductGroupID, Visit, ProductName,
        Price, OldPrice, mojud, BrandID, ShortDiscrib, CreateTime,
        fulldesc, image, status, forushgah } = req.body;


    try {

        const st = await product.findOne({

            where: {

                id: req.params.id
            }
        })


        await product.update({
            ProductShenase: ProductShenase,
            ProductGroupID: ProductGroupID,
            Visit: Visit,
            ProductName: ProductName,
            Price: Price,
            OldPrice: OldPrice,
            mojud: mojud,
            BrandID: BrandID,
            ShortDiscrib: ShortDiscrib,
            CreateTime: CreateTime,
            fulldesc: fulldesc,
            image: image,
            status: status,
            forushgah: forushgah,

        }, {
            where: {
                id: req.params.id
            }
        })



        res.json("product updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("product update faild")
    }




}

export const disableproduct = async (req, res) => {

    /////////////sample/////////////////////

    const { ProductShenase, ProductGroupID, Visit, ProductName,
        Price, OldPrice, mojud, BrandID, ShortDiscrib, CreateTime,
        fulldesc, image, status, forushgah } = req.body;

    try {

        const st = await product.findOne({

            where: {

                id: req.params.id
            }
        })


        await product.update({
            ProductShenase: ProductShenase,
            ProductGroupID: ProductGroupID,
            Visit: Visit,
            ProductName: ProductName,
            Price: Price,
            OldPrice: OldPrice,
            mojud: mojud,
            BrandID: BrandID,
            ShortDiscrib: ShortDiscrib,
            CreateTime: CreateTime,
            fulldesc: fulldesc,
            image: image,
            status: 0,
            forushgah: forushgah,

        }, {
            where: {
                id: req.params.id
            }
        })



        res.json("product updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("product update faild")
    }




}

 
export const getproductBynewaddedTime = async (req, res) => {
    try {
        const st = await product.findAll({
            order: [['CreateTime', 'DESC']], where: {
                status: 1
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}
export const getSproductByrangePrice = async (req, res) => {
    try {
        const st = await product.findAll({
            where: {
                Price: { [Op.gt]: req.params.minPrice },
                Price: { [Op.lt]: req.params.maxPrice },
                status: 1
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}
export const getProductByLikeName = async (req, res) => {
    try {
        const st = await product.findAll({
            where: {
               status:1,


               ProductName: {
                [Op.like]: '%'+req.params.ProductName+'%',
              },


            }

        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

 