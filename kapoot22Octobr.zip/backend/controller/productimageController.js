import { Sequelize } from "sequelize";
import productimage from "../models/productimage.js";



export const getproductimage = async (req, res) => {
    try {
        const pi = await productimage.findAll({});
        res.json(pi);
    } catch (error) {
        console.log(error)
    }
}

export const addproductimage = async (req, res) => {

 
    const { title, productId } = req.body;
     try {

        console.log(req.body)
        await productimage.create({
            title: title,
            productId: productId,
     
        })
        res.json({ message: "productimage added success" })
    } catch (error) {
        console.log("productimage added faild")
    }
}
 
export const getproductimageByProductID = async (req, res) => {
    try {
        const st = await productimage.findAll({
            where: {
                productId: req.params.productId
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const deleteproductimage = async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await productimage.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("تصویر وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await productimage.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("تصویر حذف شد")
    } catch (error) {
        console.log("تصویر وجود ندارد")
    }
}

export const updateproductimage= async (req, res) => {

    /////////////sample/////////////////////
    const { title, productId } = req.body;


    try {

        const st = await productimage.findOne({

            where: {

                id: req.params.id
            }
        })


        await productimage.update({
            title: title,
            productId: productId,

        }, {
                where: {
                    id: req.params.id
                }
            })



        res.json("image updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("image update faild")
    }




}




 