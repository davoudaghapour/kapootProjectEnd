import { Sequelize } from "sequelize";
import bannerStoryStatus from "../models/bannerStoryStatus.js";



export const getbannerStoryStatus = async (req, res) => {
    try {
        const s = await bannerStoryStatus.findAll({});
        res.json(s);
    } catch (error) {
        console.log(error)
    }
}

export const addbannerStoryStatus = async (req, res) => {

 
    const { title } = req.body;
     try {

        console.log(req.body)
        await bannerStoryStatus.create({
            title: title,
           
        })
        res.json({ message: "status added success" })
    } catch (error) {
        console.log("status added faild")
    }
}
 
 

export const deletebannerStoryStatus = async (req, res) => {
 
    const st = await bannerStoryStatus.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("وضعیت وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await bannerStoryStatus.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("وضعیت حذف شد")
    } catch (error) {
        console.log("وضعیت وجود ندارد")
    }
}
 




 