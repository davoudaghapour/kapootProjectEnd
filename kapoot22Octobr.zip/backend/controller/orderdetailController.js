import { Sequelize } from "sequelize";
import orderdetail from "../models/orderdetail.js";





export const getorderdetail = async (req, res) => {
    try {
        const o = await orderdetail.findAll({});
        res.json(o);
    } catch (error) {
        console.log(error)
    }
}

export const addorderdetail = async (req, res) => {


    const { OrderID, ProductTitle, ImgName, ProductPrice } = req.body;
    try {

        console.log(req.body)
        await orderdetail.create({
            OrderID: OrderID,
            ProductTitle: ProductTitle,
            ImgName: ImgName,
            ProductPrice: ProductPrice,
        })
        res.json({ message: "orderDetail added success" })
    } catch (error) {
        console.log("orderDetail added faild")
    }
}
 

export const getorderdetailByOrderID = async (req, res) => {
    try {
        const o = await orderdetail.findAll({
            where: {
                OrderID: req.params.OrderID

            }
        });
        res.json(o);
    } catch (error) {
        console.log(error)
    }
}

export const deleteorderdetail = async (req, res) => {
 
    const o = await orderdetail.findOne({ where: { id: req.params.id } })
    console.log(o)
    if (!o) {
        return res.json(" سفارش وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await orderdetail.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("سفارش حذف شد")
    } catch (error) {
        console.log("سفارش وجود ندارد")
    }
}

 










