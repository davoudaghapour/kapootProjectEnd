import { Sequelize } from "sequelize";
import Stories from "../models/banners.js";



export const getBanners = async (req, res) => {
    try {
        const b = await banners.findAll({});
        res.json(b);
    } catch (error) {
        console.log(error)
    }
}


export const addBanners = async (req, res) => {
    const { ImageName, ImageLink
    } = req.body;

     try {
        await banners.create({
            ImageName: ImageName,
            ImageLink: ImageLink,
            status: 0
        })
        res.json({ message: "story added success" })
    } catch (error) {
        console.log("story added faild")
    }
}

export const getActiveBanner = async (req, res) => {
    try {
        const banners = await banners.findAll({
            where: {
                status: 0
            }
        });
        res.json(banners);
    } catch (error) {
        console.log(error)
    }
}

export const getBannerByUserID = async (req, res) => {
    try {
        const b = await banners.findAll({
            where: {
                userId: req.params.userId
            }
        });
        res.json(b);
    } catch (error) {
        console.log(error)
    }
}

export const delBanner = async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await banners.findOne({ where: { id: req.params.id } })
    // res.json(" del user")
    if (!st) {
        return res.json("بنر وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await banners.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("بنر حذف شد")
    } catch (error) {
        console.log("بنر وجود ندارد")
    }
}

export const updateBanner = async (req, res) => {

    /////////////sample/////////////////////

    const { ImageName, ImageLink, status
    } = req.body;

    try {

        const st = await banners.findOne({

            where: {

                id: req.params.id
            }
        })


        await banners.update({
            ImageName: ImageName,
            ImageLink: ImageLink,
            status: status

        }, {
                where: {
                    id: req.params.id
                }
            })



        res.json("banner updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("banner update faild")
    }




}

export const disableBanner = async (req, res) => {

    /////////////sample/////////////////////

    const { ImageName, ImageLink, status
    } = req.body;

    try {

        const st = await banners.findOne({

            where: {

                id: req.params.id
            }
        })


        await banners.update({
            ImageName: ImageName,
            ImageLink: ImageLink,
            status: 0
        }, {
                where: {
                    id: req.params.id
                }
            })
        res.json("banners updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("banners update faild")
    }

}










 