import { Sequelize } from "sequelize";
import productgroup from "../models/productgroup.js";



export const getproductgroup = async (req, res) => {
    try {
        const pg = await productgroup.findAll({});
        res.json(pg);
    } catch (error) {
        console.log(error)
    }
}

export const addproductgroup= async (req, res) => {

 
    const { ProductGroupTItle, ParentID } = req.body;
     try {

        console.log(req.body)
        await productgroup.create({
            ProductGroupTItle: ProductGroupTItle,
            ParentID: ParentID,
     
        })
        res.json({ message: "productgroup added success" })
    } catch (error) {
        console.log("productgroup added faild")
    }
}
 
export const getproductgroupByParentID = async (req, res) => {
    try {
        const st = await productgroup.findAll({
            where: {
                ParentID: req.params.ParentID
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const deleteproductgroup = async (req, res) => {
 
    const st = await productgroup.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("گروه وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await productgroup.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("گروه حذف شد")
    } catch (error) {
        console.log("گروه وجود ندارد")
    }
}

export const updateproductgroup = async (req, res) => {

    /////////////sample/////////////////////
    const { ProductGroupTItle, ParentID } = req.body;

    try {

        const st = await productgroup.findOne({

            where: {

                id: req.params.id
            }
        })


        await productgroup.update({
            ProductGroupTItle: ProductGroupTItle,
            ParentID: ParentID,

        }, {
                where: {
                    id: req.params.id
                }
            })



        res.json("productgroup updated")
     } catch (error) {
        console.log("productgroup update faild")
    }




}

  




 