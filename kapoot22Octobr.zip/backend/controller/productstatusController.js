import { Sequelize } from "sequelize";
import productstatus from "../models/productstatus.js";



export const getproductstatus = async (req, res) => {
    try {
        const ps = await productstatus.findAll({});
        res.json(ps);
    } catch (error) {
        console.log(error)
    }
}

export const addproductstatus= async (req, res) => {

 
    const { title  } = req.body;
     try {

        console.log(req.body)
        await productstatus.create({
            title: title,
          
        })
        res.json({ message: "productstatus added success" })
    } catch (error) {
        console.log("productstatus added faild")
    }
}

export const getproductstatusID = async (req, res) => {
    try {
        const st = await productstatus.findAll({
            where: {
                id: req.params.id
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const deleteproductstatus= async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await productstatus.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("وضعیت وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await productstatus.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("وضعیت حذف شد")
    } catch (error) {
        console.log("وضعیت وجود ندارد")
    }
}

export const updateproductstatus = async (req, res) => {

    /////////////sample/////////////////////

    const { title 
    } = req.body;

    try {

        const st = await productstatus.findOne({

            where: {

                id: req.params.id
            }
        })


        await productstatus.update({
            title: title,
            

        }, {
                where: {
                    id: req.params.id
                }
            })



        res.json("status updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("status update faild")
    }




}

 
 







 