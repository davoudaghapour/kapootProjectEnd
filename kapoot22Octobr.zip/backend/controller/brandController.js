import { Sequelize } from "sequelize";
import brands from "../models/brands.js";



export const getbrands = async (req, res) => {
    try {
        const informations = await brands.findAll({});
        res.json(informations);
    } catch (error) {
        console.log(error)
    }
}

export const addbrands = async (req, res) => {

 
    const { title, userId, link } = req.body;
     try {
        await brands.create({
            title: title,
            userId: userId,
            link: link,
            status: 0,
        })
        res.json({ message: "story added success" })
    } catch (error) {
        console.log("story added faild")
    }
}
 
export const getbrandsByID = async (req, res) => {
    try {
        const Stories = await brands.findAll({
            where: {
                Id: req.params.Id
            }
        });
        res.json(Stories);
    } catch (error) {
        console.log(error)
    }
}

export const delbrands = async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await brands.findOne({ where: { id: req.params.id } })
    // res.json(" del user")
    if (!st) {
        return res.json("برند وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await brands.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("برند حذف شد")
    } catch (error) {
        console.log("برند وجود ندارد")
    }
}

export const updatebrands = async (req, res) => {

    const { brandName, brandImg, brandLink 
    } = req.body;

    try {
        const st = await brands.findOne({
            where: {
                id: req.params.id
            }
        })
        await brands.update({
            brandName: brandName,
            brandImg: brandImg,
            brandLink: brandLink,

        }, {
                where: {
                    id: req.params.id
                }
            })

        res.json("brand updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("brand update faild")
    }

}

 
export const disablebrands = async (req, res) => {

    const { brandName, brandImg, brandLink 
    } = req.body;
    try {
        const st = await brands.findOne({

            where: {

                id: req.params.id
            }
        })

        await brands.update({
            brandName: brandName,
            brandImg: brandImg,
            brandLink: brandLink,
        }, {
                where: {
                    id: req.params.id
                }
            })
        res.json("brand updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("bransd update faild")
    }
}


