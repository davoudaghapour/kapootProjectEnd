import { Sequelize } from "sequelize";
import order from "../models/order.js";





export const getorder = async (req, res) => {
    try {
        const o = await order.findAll({});
        res.json(o);
    } catch (error) {
        console.log(error)
    }
}

export const addorder = async (req, res) => {


    const { Sum, userID, CreatFactor, IsSucsess } = req.body;
    try {

        console.log(req.body)
        await Stories.create({
            userID: userID,
            Sum: Sum,
            CreatFactor: CreatFactor,
            IsSucsess: false,
        })
        res.json({ message: "order added success" })
    } catch (error) {
        console.log("order added faild")
    }
}

export const getSuccessOrder = async (req, res) => {
    try {
        const o = await order.findAll({
            where: {
                IsSucsess: true

            }
        });
        res.json(o);
    } catch (error) {
        console.log(error)
    }
}

export const getorderByUserID = async (req, res) => {
    try {
        const o = await order.findAll({
            where: {
                userID: req.params.userID

            }
        });
        res.json(o);
    } catch (error) {
        console.log(error)
    }
}

export const deleteOrder = async (req, res) => {
 
    const o = await order.findOne({ where: { id: req.params.id } })
    console.log(o)
    if (!o) {
        return res.json(" سفارش وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await order.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("سفارش حذف شد")
    } catch (error) {
        console.log("سفارش وجود ندارد")
    }
}

export const updateOrder = async (req, res) => {

    /////////////sample/////////////////////

    const { Sum, userID, CreatFactor, IsSucsess } = req.body;


    try {

        const st = await order.findOne({

            where: {

                id: req.params.id
            }
        })


        await order.update({
            userID: userID,
            CreatFactor: CreatFactor,
            Sum: Sum,
            IsSucsess: IsSucsess,

        }, {
            where: {
                id: req.params.id
            }
        })



        res.json("order updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("order update faild")
    }




}











