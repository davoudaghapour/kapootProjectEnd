import { Sequelize } from "sequelize";
import productcomment from "../models/productcomment.js";



export const getproductcomment = async (req, res) => {
    try {
        const pc = await productcomment.findAll({});
        res.json(pc);
    } catch (error) {
        console.log(error)
    }
}

export const getcommentByProductId = async (req, res) => {
    try {
        const pc = await productcomment.findAll({
            where: {
                productID: req.params.productID
            }
        });
        res.json(pc);
    } catch (error) {
        console.log(error)
    }
}

export const getcommentByuserID = async (req, res) => {
    try {
        const pc = await productcomment.findAll({
            where: {
                userID: req.params.userID
            }
        });
        res.json(pc);
    } catch (error) {
        console.log(error)
    }
}

export const addproductcomment = async (req, res) => {

 
    const { userID, Comment, productID,email } = req.body;
     try {

        console.log(req.body)
        await productcomment.create({
            userID: userID,
            Comment: Comment,
            productID: productID,
            email: email,
            DateTIme:Date.now()
        })
        res.json({ message: "comment added success" })
    } catch (error) {
        console.log("comment added faild")
    }
}

export const deleteproductcomment= async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await productcomment.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("نظر وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await productcomment.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("نظر حذف شد")
    } catch (error) {
        console.log("نظر وجود ندارد")
    }
}

 


 