import { Sequelize } from "sequelize";
import userstatuse from "../models/userstatuse.js";



export const getuserstatuse = async (req, res) => {
    try {
        const ps = await userstatuse.findAll({});
        res.json(ps);
    } catch (error) {
        console.log(error)
    }
}

export const adduserstatuse= async (req, res) => {

 
    const { title  } = req.body;
     try {

        console.log(req.body)
        await userstatuse.create({
            title: title,
          
        })
        res.json({ message: "userstatuse added success" })
    } catch (error) {
        console.log("userstatuse added faild")
    }
}

export const getuserstatuseID = async (req, res) => {
    try {
        const st = await userstatuse.findAll({
            where: {
                id: req.params.id
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const deleteuserstatuse= async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await userstatuse.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("وضعیت وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await userstatuse.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("وضعیت حذف شد")
    } catch (error) {
        console.log("وضعیت وجود ندارد")
    }
}

export const updateuserstatuse = async (req, res) => {

    /////////////sample/////////////////////

    const { title 
    } = req.body;

    try {

        const st = await userstatuse.findOne({

            where: {

                id: req.params.id
            }
        })


        await userstatuse.update({
            title: title,
            

        }, {
                where: {
                    id: req.params.id
                }
            })



        res.json("status updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("status update faild")
    }




}

 
 







 