import { Sequelize } from "sequelize";
import Stories from "../models/stories.js";



export const getStories = async (req, res) => {
    try {
        const informations = await Stories.findAll({});
        res.json(informations);
    } catch (error) {
        console.log(error)
    }
}

export const addStory = async (req, res) => {

 
    const { title, userId, link } = req.body;
     try {

        console.log(req.body)
        await Stories.create({
            title: title,
            userId: userId,
            link: link,
            status: 0,
        })
        res.json({ message: "story added success" })
    } catch (error) {
        console.log("story added faild")
    }
}

export const getActiveStories = async (req, res) => {
    try {
        const st = await Stories.findAll({
            where: {
                status: 0
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const getStoryByUserID = async (req, res) => {
    try {
        const st = await Stories.findAll({
            where: {
                userId: req.params.userId
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const deleteStory = async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await Stories.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("استوری وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await Stories.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("استوری حذف شد")
    } catch (error) {
        console.log("استوری وجود ندارد")
    }
}

export const updatestory = async (req, res) => {

    /////////////sample/////////////////////

    const { title, userId, link, status
    } = req.body;

    try {

        const st = await Stories.findOne({

            where: {

                id: req.params.id
            }
        })


        await Stories.update({
            title: title,
            userId: userId,
            link: link,
            status: status,

        }, {
                where: {
                    id: req.params.id
                }
            })



        res.json("story updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("story update faild")
    }




}

 
export const disableStory = async (req, res) => {

    /////////////sample/////////////////////

    const { title, userId, link, status
    } = req.body;

    try {

        const st = await Stories.findOne({

            where: {

                id: req.params.id
            }
        })


        await Stories.update({
            title: title,
            userId: userId,
            link: link,
            status: 0

        }, {
                where: {
                    id: req.params.id
                }
            })



        res.json("story updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("story update faild")
    }




}












export const getStoriesById = async (req, res) => {

}


export const getStoriesByname = async (req, res) => {

}



export const addStories = async (req, res) => {

}


export const editStories = async (req, res) => {

}


export const delStories = async (req, res) => {

}