import { Sequelize } from "sequelize";
import SiteInfo from "../models/SiteInfoes.js";
 


export const getSiteInfoes = async (req, res) => {
    try {
        const informations = await SiteInfo.findAll({});
        res.json(informations);
    } catch (error) {
        console.log(error)
    }

}

export const getFirstSiteInfo = async (req, res) => {
    try {
        const i = await SiteInfo.findOne({});
        res.json(i);
    } catch (error) {
        console.log(error)
    }
}

export const addSiteInfo= async (req, res) => {

 
    const { SiteName, SiteShortDisc, SiteDiscribtion,AboutUS,
        Tell1,Tell2,Tell3,Tell5,Email,SiteLog,SiteRouls,Address } = req.body;
        
     try {

        console.log(req.body)
        await SiteInfo.create({
            SiteName: SiteName,
            SiteShortDisc: SiteShortDisc,
            SiteDiscribtion: SiteDiscribtion,
            AboutUS: AboutUS,
            Tell1: Tell1,
            Tell2: Tell2,
            Tell3: Tell3,
            Tell5: Tell5,
            Email: Email,
            SiteLog: SiteLog,
            SiteRouls: SiteRouls,
            Address: Address,
           
        })
        res.json({ message: "SiteInfo added success" })
    } catch (error) {
        console.log("SiteInfo added faild")
    }
}
 export const deleteSiteInfo= async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await SiteInfo.findOne({ where: { SiteInfoID: req.params.SiteInfoID } })
    console.log(st)
    if (!st) {
        return res.json("اطلاعات سایت وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await Stories.destroy({
            where: {
                SiteInfoID: req.params.SiteInfoID
            }
        })
        res.json("اطلاعات سایت حذف شد")
    } catch (error) {
        console.log("اطلاعات سایت وجود ندارد")
    }
}

export const updateSiteInfo = async (req, res) => {

    /////////////sample/////////////////////
    const { SiteName, SiteShortDisc, SiteDiscribtion,AboutUS,
        Tell1,Tell2,Tell3,Tell5,Email,SiteLog,SiteRouls,Address } = req.body;
        
    try {

        const st = await SiteInfo.findOne({

            where: {

                SiteInfoID: req.params.SiteInfoID
            }
        })


        await SiteInfo.update({
            SiteName: SiteName,
            SiteShortDisc: SiteShortDisc,
            SiteDiscribtion: SiteDiscribtion,
            AboutUS: AboutUS,
            Tell1: Tell1,
            Tell2: Tell2,
            Tell3: Tell3,
            Tell5: Tell5,
            Email: Email,
            SiteLog: SiteLog,
            SiteRouls: SiteRouls,
            Address: Address,

        }, {
                where: {
                    SiteInfoID: req.params.SiteInfoID
                }
            })



        res.json("SiteInfo updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("SiteInfo update faild")
    }




}

 
 




 