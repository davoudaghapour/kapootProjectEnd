import { Sequelize } from "sequelize";
import SiteMenu_db from "../models/siteMenu.js";
 





export const getSiteMenu = async (req, res) => {
    try {
        const data = await SiteMenu_db.findAll({});
        res.json(data);
    } catch (error) {
        console.log(error)
    }

}







export const getAllSiteMenu = async (req, res) => {
    try {
        const SiteMenus = await SiteMenus.findAll({});
        res.json(SiteMenus);
    } catch (error) {
        console.log(error)
    }

}



export const getSiteMenuById = async (req, res) => {
    

}


export const getSiteMenuByname = async (req, res) => {
    

}



export const addSiteMenu = async (req, res) => {
    

}


export const editSiteMenu = async (req, res) => {
    

}


export const delSiteMenu = async (req, res) => {
    

}

 