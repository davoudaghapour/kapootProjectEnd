import { Sequelize } from "sequelize";
import userrule from "../models/userrule.js";



export const getuserrule = async (req, res) => {
    try {
        const ur = await userrule.findAll({});
        res.json(ur);
    } catch (error) {
        console.log(error)
    }
}

export const adduserrule = async (req, res) => {

 
    const { title  } = req.body;
     try {

        console.log(req.body)
        await userrule.create({
            title: title,
           
        })
        res.json({ message: "userrule added success" })
    } catch (error) {
        console.log("userrule added faild")
    }
}
 
export const getuserruleByID = async (req, res) => {
    try {
        const st = await userrule.findOne({
            where: {
                id: req.params.id
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const deleteuserrule = async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await userrule.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("نقش وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await userrule.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("نقش حذف شد")
    } catch (error) {
        console.log("نقش وجود ندارد")
    }
}

export const updateuserrule = async (req, res) => {

    /////////////sample/////////////////////

    const { title } = req.body;

    try {

        const st = await userrule.findOne({

            where: {

                id: req.params.id
            }
        })


        await userrule.update({
            title: title,
            

        }, {
                where: {
                    id: req.params.id
                }
            })



        res.json("userrule updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("userrule update faild")
    }
 
}

  
 