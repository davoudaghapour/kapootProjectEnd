import { Sequelize } from "sequelize";
import productdetail from "../models/productdetail.js";




export const getproductdetail = async (req, res) => {
    try {
        const pd = await productdetail.findAll({});
        res.json(pd);
    } catch (error) {
        console.log(error)
    }
}

export const addproductdetail = async (req, res) => {


    const { ProductID, ProductDetailTItle, ProductDetailText } = req.body;
    try {

        console.log(req.body)
        await productdetail.create({
            ProductID: ProductID,
            ProductDetailTItle: ProductDetailTItle,
            ProductDetailText: ProductDetailText,
        })
        res.json({ message: "productdetail added success" })
    } catch (error) {
        console.log("productdetail added faild")
    }
}


export const getproductdetailByProductID = async (req, res) => {
    try {
        const st = await productdetail.findAll({
            where: {
                ProductID: req.params.ProductID
            }
        });
        res.json(st);
    } catch (error) {
        console.log(error)
    }
}

export const deleteproductdetail = async (req, res) => {
    /////////////sample/////////////////////
    // Create a new user
    // const { Password, phoneNumber } = req.body;
    //  console.log(Password, phoneNumber);
    //  res.json(" del user")
    const st = await productdetail.findOne({ where: { id: req.params.id } })
    console.log(st)
    if (!st) {
        return res.json("جزییات وجود ندارد")
    }
    try {
        // return res.json(found.Password)
        await productdetail.destroy({
            where: {
                id: req.params.id
            }
        })
        res.json("جزییات حذف شد")
    } catch (error) {
        console.log("جزییات وجود ندارد")
    }
}

export const updateproductdetail = async (req, res) => {

    /////////////sample/////////////////////
    const { ProductID, ProductDetailTItle, ProductDetailText } = req.body;


    try {

        const st = await productdetail.findOne({

            where: {

                id: req.params.id
            }
        })


        await productdetail.update({
            ProductID: ProductID,
            ProductDetailTItle: ProductDetailTItle,
            ProductDetailText: ProductDetailText,

        }, {
            where: {
                id: req.params.id
            }
        })



        res.json("productdetail updated")
        //res.json({ message: "update is success" })
    } catch (error) {
        console.log("productdetail update faild")
    }

}








