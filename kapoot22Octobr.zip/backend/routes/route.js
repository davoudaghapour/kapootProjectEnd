import express from "express";


import { getAllUser } from "../controller/usercontroller.js";



const router = express.Router();


router.get("/api/users", getAllUser);




export default router;