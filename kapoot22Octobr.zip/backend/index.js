import express from "express";
import router from "./routes/route.js";
import db from "./config/database.js";
import cors from "cors"
import { getAllUser, register, login, delUser, updateUser, getUserById } from "./controller/usercontroller.js";
import { getSiteInfoes,addSiteInfo,deleteSiteInfo,getFirstSiteInfo,updateSiteInfo } from "./controller/siteInfoController.js";
import { getSiteMenu } from "./controller/siteMenuController.js";
import { getStories, addStory, getActiveStories, deleteStory, getStoryByUserID, updatestory, disableStory } from "./controller/storiesController.js";
import { delBanner, addBanners, disableBanner, getActiveBanner, getBanners, updateBanner, getBannerByUserID } from "./controller/bannerController.js"
import { addbrands, delbrands, disablebrands, getbrands, getbrandsByID, updatebrands } from "./controller/brandController.js"
import { addbannerStoryStatus, getbannerStoryStatus, deletebannerStoryStatus } from "./controller/bannerStoryStatusController.js"
import { addorder, deleteOrder, getSuccessOrder, getorder, getorderByUserID, updateOrder, } from "./controller/orderController.js"
import { addproduct, deleteproduct, disableproduct, getActiveproduct, getMojudproduct, getProductByLikeName, getSproductByrangePrice, getproductByBrandID, getproductByGroupID, getproductByShenase, getproductByforushgahID, getproductBynewaddedTime, getproducts, updateproduct } from "./controller/productController.js"

import fileUpload from "express-fileupload";
import path from "path"




const app = express();
app.use(express.json());
app.use(router);
app.use(fileUpload());
app.use(cors());
app.use(express.static(path.join('./public/Images/', 'dist/application')));
/*
try {

   await db.authenticate();

   console.log("db connected");
   await db.sync();


} catch (error) {
   console.log(error)}
*/

app.get("/", (req, res) => {
    res.json("host connected");
})

/////////////////user rout //////////////////////
app.get("/users", getAllUser)
app.post("/register", register)
app.post("/login", login)
app.delete("/delUser/:id", delUser)
app.put("/updateUser/:id", updateUser)
app.get("/getUserById/:id", getUserById)

///////////////siteInfo - site Menu Rout///////////
app.get("/siteinfo", getSiteInfoes)
app.get("/sitemenu", getSiteMenu)


app.get("/getSiteInfoes", getSiteInfoes)
app.get("/getFirstSiteInfo", getFirstSiteInfo)
app.delete("/deleteSiteInfo/:SiteInfoID", deleteSiteInfo)
app.post("/addSiteInfo", addSiteInfo)
app.put("/updateSiteInfo/:id", updateSiteInfo)
 
/////////////story rout /////////////
app.get("/getStories", getStories)
app.post("/addStory", addStory)
app.get("/getActiveStories", getActiveStories)
app.delete("/deleteStory/:id", deleteStory)
app.get("/getStoryByUserID/:UserId", getStoryByUserID)
app.put("/updatestory/:id", updatestory)
app.get("/disableStory/:id", disableStory)
///////////////// banner rout///////////
app.get("/getBanners", getBanners)
app.post("/addBanners", addBanners)
app.get("/getActiveBanner", getActiveBanner)
app.delete("/delBanner/:id", delBanner)
app.get("/getBannerByUserID/:UserId", getBannerByUserID)
app.put("/updateBanner/:id", updateBanner)
app.get("/disableBanner/:id", disableBanner)
///////////////// banner rout///////////
app.get("/getbrands", getbrands)
app.post("/addbrands", addbrands)
app.delete("/delbrands/:id", delbrands)
app.get("/getbrandsByID/:id", getbrandsByID)
app.put("/updatebrands/:id", updatebrands)
app.get("/disablebrands/:id", disablebrands)
///////////////bannerStoryStatus///////////////
app.get("/getbannerStoryStatus", getbannerStoryStatus)
app.post("/addbannerStoryStatus", addbannerStoryStatus)
app.delete("/deletebannerStoryStatus/:id", deletebannerStoryStatus)
//////////////////////order//////////////////////////
app.get("/getorder", getorder)
app.post("/addorder", addorder)
app.get("/getSuccessOrder", getSuccessOrder)
app.get("/getorderByUserID/:userID", getorderByUserID)
app.delete("/deleteOrder/:id", deleteOrder)
app.put("/updateOrder/:id", updateOrder)
//////////////////////orderDetail//////////////////////////
app.get("/getorderdetail", getorderdetail)
app.post("/addorderdetail", addorderdetail)
app.get("/getorderdetailByOrderID/:OrderID", getorderdetailByOrderID)
app.delete("/deleteorderdetail/:id", deleteOrder)
//////////////////////product//////////////////////////
app.get("/getproducts", getproducts)
app.post("/addproduct", addproduct)
app.get("/getActiveproduct", getActiveproduct)
app.get("/getMojudproduct", getMojudproduct)
app.get("/getproductByBrandID/:BrandID", getproductByBrandID)
app.get("/getproductByforushgahID/:forushgah", getproductByforushgahID)
app.get("/getproductByShenase/:ProductShenase", getproductByShenase)
app.get("/getproductByGroupID/:ProductGroupID", getproductByGroupID)
app.delete("/deleteproduct/:id", deleteproduct)
app.put("/updateproduct/:id", updateproduct)
app.put("/disableproduct/:id", disableproduct)
app.get("/getproductBynewaddedTime", getproductBynewaddedTime)
app.get("/getSproductByrangePrice?:minPrice&:maxPrice", getSproductByrangePrice)
app.get("/getProductByLikeName/:ProductName", getProductByLikeName)
///////////////////////////product comment//////////////////////////////////////
app.get("/getproductcomment", getproductcomment)
app.get("/getcommentByProductId/:productID", getcommentByProductId)
app.get("/getcommentByuserID/:userID", getcommentByuserID)
app.post("/addproductcomment", addproductcomment)
app.delete("/deleteproductcomment/:id", deleteproductcomment)
////////////////////////////////////productdetail////////////////////////////////////////////
app.get("/getproductdetail", getproductdetail)
app.get("/getproductdetailByProductID/:productID", getproductdetailByProductID)
app.get("/getcommentByuserID/:userID", getcommentByuserID)
app.post("/addproductdetail", addproductdetail)
app.delete("/deleteproductdetail/:id", deleteproductdetail)
app.put("/updateproductdetail/:id", updateproductdetail)
/////////////////////////////////productgroup//////////////////////////////////////////////////
app.get("/getproductgroup", getproductgroup)
app.get("/getproductgroupByParentID/:ParentID", getproductgroupByParentID)
app.post("/addproductgroup", addproductgroup)
app.delete("/deleteproductgroup/:id", deleteproductgroup)
app.put("/updateproductgroup/:id", updateproductgroup)
/////////////////////////////////////productimage////////////////////////////////////////////////////
app.get("/getproductimage", getproductimage)
app.get("/getproductimageByProductID/:productID", getproductimageByProductID)
app.post("/addproductimage", addproductimage)
app.delete("/deleteproductimage/:id", deleteproductimage)
app.put("/updateproductimage/:id", updateproductimage)
/////////////////////////////////////productstatus///////////////////////////////////////////////////
app.get("/productstatus", productstatus)
app.get("/getproductstatusID/:id", getproductstatusID)
app.post("/addproductstatus", addproductstatus)
app.delete("/deleteproductstatus/:id", deleteproductstatus)
app.put("/updateproductstatus/:id", updateproductstatus)
/////////////////////////////////////userrule///////////////////////////////////////////////////
app.get("/getuserrule", getuserrule)
app.get("/getuserruleByID/:id", getuserruleByID)
app.post("/adduserrule", adduserrule)
app.delete("/deleteuserrule/:id", deleteuserrule)
app.put("/updateuserrule/:id", updateuserrule)
/////////////////////////////////////userStatus///////////////////////////////////////////////////
app.get("/getuserstatuse", getuserstatuse)
app.get("/getuserstatuseID/:id", getuserstatuseID)
app.post("/adduserstatuse", adduserstatuse)
app.delete("/deleteuserstatuse/:id", deleteuserstatuse)
app.put("/updateuserstatuse/:id", updateuserstatuse)

/////////////////////////////////////////////////////////////////////////////////////////////////////////
app.listen(3000, () => {
    console.log("connected")
})