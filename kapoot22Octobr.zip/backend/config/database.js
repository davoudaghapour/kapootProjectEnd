import { Sequelize } from "sequelize";


//const db="";
 const db=new Sequelize("kapoot_db_2024","root","",{
 host:"localhost",
 dialect:"mysql",
 define:{
    timestamps:false
 }
 });


export default db;